from PyQt5 import QtCore, QtGui, QtWidgets
import MySQLdb as mdb


class Ui_Page13(object):
    
    def Page12(self): # import and indentify page12
        from Page12 import Ui_Page12
        self.window2 = QtWidgets.QMainWindow()
        self.ui = Ui_Page12()
        self.ui.setupUi(self.window2)
        self.window2.show()
    
    
    def Page14(self): # import and identify page14
        from Page14 import Ui_Page14
        self.window2 = QtWidgets.QMainWindow()
        self.ui = Ui_Page14()
        self.ui.setupUi(self.window2)
        self.window2.show()
        
        
    risk_grade = 0
    # method that connects to database and fetches data
    def DB(self):
        try:
            connection = mdb.connect("localhost","root","root","coolmind")
            cursor = connection.cursor() # object
            print("Your are connected to Database")
            
            cursor = connection.cursor()
        except Exception as e:
            print("Database not connected")
    
        # SQL query that fetches data from table question2 in MYSQL, order by decending (fetches last row) and fetch only one row
        cursor.execute (  
                "SELECT * FROM question2 ORDER BY id DESC LIMIT 1;"
            )
        
        result = cursor.fetchall()
        data_question2 = result [0]
     #   print ("risk level of question 2 = ", data_question2)

        cursor.execute (  # SQL query that fetches data from table question3 in MYSQL, order by decending (fetches last row) and fetch only one row
                "SELECT * FROM question3 ORDER BY id DESC LIMIT 1;"
            )
        
        result = cursor.fetchall()
        data_question3 = result [0]
     #   print ("risk level of question 3 = ", data_question3)
        
        cursor.execute (  # SQL query that fetches data from table question4 in MYSQL, order by decending (fetches last row) and fetch only one row
                "SELECT * FROM question4 ORDER BY id DESC LIMIT 1;"
            )
        
        result = cursor.fetchall()
        data_question4 = result [0]
    #    print ("risk level of question 4 = ", data_question4)
        
        cursor.execute (  # SQL query that fetches data from table question5 in MYSQL, order by decending (fetches last row) and fetch only one row
                "SELECT * FROM question5 ORDER BY id DESC LIMIT 1;"
            )
        
        result = cursor.fetchall()
        data_question5 = result [0]
      #  print ("risk level of question 5 = ", data_question5)
        
        cursor.execute (  # SQL query that fetches data from table question6 in MYSQL, order by decending (fetches last row) and fetch only one row
                "SELECT * FROM question6 ORDER BY id DESC LIMIT 1;"
            )
        
        result = cursor.fetchall()
        data_question6 = result [0]
     #   print ("risk level of question 6 = ", data_question6)
        
        cursor.execute (  # SQL query that fetches data from table question7 in MYSQL, order by decending (fetches last row) and fetch only one row
                "SELECT * FROM question7 ORDER BY id DESC LIMIT 1;"
            )
        
        result = cursor.fetchall()
        data_question7 = result [0]
    #    print ("risk level of question 7 = ", data_question7)
        
        cursor.execute (  # SQL query that fetches data from table question8 in MYSQL, order by decending (fetches last row) and fetch only one row
                "SELECT * FROM question8 ORDER BY id DESC LIMIT 1;"
            )
        
        result = cursor.fetchall()
        data_question8 = result [0]
    #    print ("risk level of question 8 = ", data_question8)

        cursor.execute (  # SQL query that fetches data from table question9 in MYSQL, order by decending (fetches last row) and fetch only one row
                "SELECT * FROM question9 ORDER BY id DESC LIMIT 1;"
            )
        
        result = cursor.fetchall()
        data_question9 = result [0]
    #    print ("risk level of question 11 = ", data_question9)

        # setting risk grade based on the users choice
        
        risk_grade_q2 = 0 # How often do you feel this way?
        if data_question2 [0] == "1": # index id
            risk_grade_q2 = 0         # Grade
        elif data_question2 [1] == "1": # index once a week 
            risk_grade_q2 = 1           # Grade
        elif data_question2 [2] == "1": # index twice a week
            risk_grade_q2 = 2
        elif data_question2 [3] == "1": # index Idont know 
            risk_grade_q2 = 5
            
        
        risk_grade_q3 = 0 # How often do you exersice? 
        if data_question3 [0] == "1": # index id
            risk_grade_q3 = 0
        elif data_question3 [1] == "1": # index once a week 
            risk_grade_q3 = 2
        elif data_question3 [2] == "1": # index More than once a week 
            risk_grade_q3 = 1
        elif data_question3 [3] == "1": # index Not at all
            risk_grade_q3 = 5
        
        risk_grade_q4 = 0 #  how often do you participate in leisure you enjoy?
        if data_question4 [0] == "1": # index id 
            risk_grade_q4 = 0
        elif data_question4 [1] == "1": # index once a week 
            risk_grade_q4 = 2
        elif data_question4 [2] == "1": # index more than once a week 
            risk_grade_q4 = 1
        elif data_question4 [3] == "1": # index Not at all
            risk_grade_q4 = 5
        
        
        risk_grade_q5 = 0 # When did you east properly? 
        if data_question5 [0] == "1": # index id
            risk_grade_q5 = 0
        elif data_question5 [1] == "1": # index Today
            risk_grade_q5 = 1
        elif data_question5 [2] == "1": # index a few days ago
            risk_grade_q5 = 5
        elif data_question5 [3] == "1": # index I dont know
            risk_grade_q5 = 10 
        
        risk_grade_q6 = 0 # How many hourd do you sleep? 
        if data_question6 [0] == "1": # index id
            risk_grade_q6 = 0
        elif data_question6 [1] == "1": # index 6-9 hours
            risk_grade_q6 = 1
        elif data_question6 [2] == "1": # index less than 6 hours
            risk_grade_q6 = 5
        elif data_question6 [3] == "1": # Index i dont know
            risk_grade_q6 = 10
       
        
        # how well read are you in the subject? scale 1-4. 4 is well read(very good), 1 is not well read(bad)
        risk_grade_q7 = 0 
        if data_question7 [0] == "1": # index for id
            risk_grade_q7 = 0 
        elif data_question7 [1] == "1": # index for 1 (not familiar of the subject)  gets 3 points
            risk_grade_q7 = 10
        elif data_question7 [2] == "1": # index for 2 ( know a little bit about the subject)  gets 2 points
            risk_grade_q7 = 4
        elif data_question7 [3] == "1": # index for 3 ( knows more about the subject)  gets 1 points
            risk_grade_q7 = 2
        elif data_question7 [4] == "1": # index for 4 ( well read in the subject)  gets 0 points
            risk_grade_q7 = 0  
        

        risk_grade_q8 = 0 # Do you have suicidal thoughts?
        if data_question8 [0] == "1": # index Id
            risk_grade_q8 = 0
        elif data_question8 [1] == "1": # index Yes
            risk_grade_q8 = 10
        elif data_question8 [1] == "1": # index NO
            risk_grade_q8 = 0 
        
        
        risk_grade_q9 = 0 # Do you have self harming behavior?
        if data_question9 [0] == "1": #index for id
            risk_grade_q9 = 0
        elif data_question9 [1] == "1": # index for yes
            risk_grade_q9 = 10   
        elif data_question9 [2] == "1": # index for NO
            risk_grade_q9 = 0 
        
        # Adding all the questions risk grade
        self.risk_grade = risk_grade_q2 + risk_grade_q3 + risk_grade_q4 +risk_grade_q5 + risk_grade_q6 + risk_grade_q7 + risk_grade_q8 + risk_grade_q9
        print ("Your total risk grade is: ",self.risk_grade)
        
    # set up for window13
    def setupUi(self, Page13):
        self.DB()
        Page13.setObjectName("Page13")
        Page13.resize(502, 617)
        self.centralwidget = QtWidgets.QWidget(Page13)
        self.centralwidget.setObjectName("centralwidget")
        # bluesky picture
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(-20, -440, 581, 1051))
        self.label.setStyleSheet("background-image: url(:/newPrefix/bluesky.jpg);")
        self.label.setText("")
        self.label.setObjectName("label")
        self.label_2 = QtWidgets.QLabel(self.centralwidget)
        self.label_2.setGeometry(QtCore.QRect(-310, -60, 1161, 921))
        self.label_2.setStyleSheet("image: url(:/newPrefix/blue sky.jpg);")
        self.label_2.setText("")
        self.label_2.setObjectName("label_2")
        # " your risk grade is" text
        self.label_6 = QtWidgets.QLabel(self.centralwidget)
        self.label_6.setGeometry(QtCore.QRect(40, 110, 451, 51))
        self.label_6.setStyleSheet("font: 75 14pt \"MS Shell Dlg 2\";")
        self.label_6.setObjectName("label_6")
        # continue button
        self.Continue_4 = QtWidgets.QPushButton(self.centralwidget)
        self.Continue_4.setGeometry(QtCore.QRect(270, 450, 141, 61))
        self.Continue_4.setStyleSheet("font: 75 16pt \"MS Shell Dlg 2\";\n"
"font: 14pt \"MS Shell Dlg 2\";\n"
"font: 16pt \"MS Shell Dlg 2\";\n"
"font: 14pt \"MS Shell Dlg 2\";")
        self.Continue_4.setObjectName("Continue_4")
        self.Continue_4.clicked.connect(self.Page14) # when user clicks continue next window opens
        self.Continue_4 .clicked.connect(Page13.close) # when user clicks continue current window closes
        # back button
        self.Back = QtWidgets.QPushButton(self.centralwidget)
        self.Back.setGeometry(QtCore.QRect(100, 450, 141, 61))
        self.Back.setStyleSheet("font: 75 16pt \"MS Shell Dlg 2\";\n"
"font: 14pt \"MS Shell Dlg 2\";\n"
"font: 16pt \"MS Shell Dlg 2\";\n"
"font: 14pt \"MS Shell Dlg 2\";")
        self.Back.setObjectName("Back")
        self.Back.clicked.connect(self.Page12) # when user clicks back previous window opens
        self.Back.clicked.connect(Page13.close) # when user clicks back current window close
        
        # Qlabel to print out the risk grade to user
        self.risk_text = QtWidgets.QLabel(self.centralwidget)
        self.risk_text.setGeometry(QtCore.QRect(100, 120, 400, 300))
        self.risk_text.setStyleSheet("font: 75 35pt \"MS Shell Dlg 2\";")
        self.risk_text.setObjectName("risk_text")
        self.risk_text.setWordWrap(True)
        self.risk_text.setNum(self.risk_grade)
        Page13.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(Page13)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 502, 26))
        self.menubar.setObjectName("menubar")
        Page13.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(Page13)
        self.statusbar.setObjectName("statusbar")
        Page13.setStatusBar(self.statusbar)

        self.retranslateUi(Page13)
        QtCore.QMetaObject.connectSlotsByName(Page13)

    def retranslateUi(self, Page13):
        _translate = QtCore.QCoreApplication.translate
        Page13.setWindowTitle(_translate("Page13", "MainWindow"))

        self.label_6.setText(_translate("Page13", "<html><head/><body><p align=\"center\"><span style=\" font-size:12pt; font-weight:400;\">Maximum risk grade is 65, Your risk grade is:</span></p></body></html>"))
        self.Continue_4.setText(_translate("Page13", "Continue"))
        self.Back.setText(_translate("Page13", "Back"))
        
        
import source13 # source for background picture


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Page13 = QtWidgets.QMainWindow()
    ui = Ui_Page13()
    ui.setupUi(Page13)
    Page13.show()
    sys.exit(app.exec_())
