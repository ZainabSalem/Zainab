
from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_Page13(object):
    
    
    def Page12(self): # import and indentify page12
        from Page12 import Ui_Page12
        self.window2 = QtWidgets.QMainWindow()
        self.ui = Ui_Page12()
        self.ui.setupUi(self.window2)
        self.window2.show()
    
    
    def Page14(self): # import and identify page14
        from Page14 import Ui_Page14
        self.window2 = QtWidgets.QMainWindow()
        self.ui = Ui_Page14()
        self.ui.setupUi(self.window2)
        self.window2.show()
    
    def setupUi(self, Page13):
        Page13.setObjectName("Page13")
        Page13.resize(502, 617)
        self.centralwidget = QtWidgets.QWidget(Page13)
        self.centralwidget.setObjectName("centralwidget")
        # bluesky picture
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(-20, -440, 581, 1051))
        self.label.setStyleSheet("background-image: url(:/newPrefix/bluesky.jpg);")
        self.label.setText("")
        self.label.setObjectName("label")
        self.label_2 = QtWidgets.QLabel(self.centralwidget)
        self.label_2.setGeometry(QtCore.QRect(-310, -60, 1161, 921))
        self.label_2.setStyleSheet("image: url(:/newPrefix/blue sky.jpg);")
        self.label_2.setText("")
        self.label_2.setObjectName("label_2")
        # " your risk grade is" text
        self.label_6 = QtWidgets.QLabel(self.centralwidget)
        self.label_6.setGeometry(QtCore.QRect(40, 110, 451, 51))
        self.label_6.setStyleSheet("font: 75 14pt \"MS Shell Dlg 2\";")
        self.label_6.setObjectName("label_6")
        # continue button
        self.Continue_4 = QtWidgets.QPushButton(self.centralwidget)
        self.Continue_4.setGeometry(QtCore.QRect(270, 450, 141, 61))
        self.Continue_4.setStyleSheet("font: 75 16pt \"MS Shell Dlg 2\";\n"
"font: 14pt \"MS Shell Dlg 2\";\n"
"font: 16pt \"MS Shell Dlg 2\";\n"
"font: 14pt \"MS Shell Dlg 2\";")
        self.Continue_4.setObjectName("Continue_4")
        self.Continue_4.clicked.connect(self.Page14)
        self.Continue_4 .clicked.connect(Page13.close)
        # back button
        self.Back = QtWidgets.QPushButton(self.centralwidget)
        self.Back.setGeometry(QtCore.QRect(100, 450, 141, 61))
        self.Back.setStyleSheet("font: 75 16pt \"MS Shell Dlg 2\";\n"
"font: 14pt \"MS Shell Dlg 2\";\n"
"font: 16pt \"MS Shell Dlg 2\";\n"
"font: 14pt \"MS Shell Dlg 2\";")
        self.Back.setObjectName("Back")
        self.Back.clicked.connect(self.Page12)
        self.Back.clicked.connect(Page13.close)
        
        
        Page13.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(Page13)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 502, 26))
        self.menubar.setObjectName("menubar")
        Page13.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(Page13)
        self.statusbar.setObjectName("statusbar")
        Page13.setStatusBar(self.statusbar)

        self.retranslateUi(Page13)
        QtCore.QMetaObject.connectSlotsByName(Page13)

    def retranslateUi(self, Page13):
        _translate = QtCore.QCoreApplication.translate
        Page13.setWindowTitle(_translate("Page13", "MainWindow"))
        self.label_6.setText(_translate("Page13", "<html><head/><body><p align=\"center\"><span style=\" font-size:16pt; font-weight:400;\">Your risk grade is:</span></p></body></html>"))
        self.Continue_4.setText(_translate("Page13", "Continue"))
        self.Back.setText(_translate("Page13", "Back"))
import source13


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Page13 = QtWidgets.QMainWindow()
    ui = Ui_Page13()
    ui.setupUi(Page13)
    Page13.show()
    sys.exit(app.exec_())
