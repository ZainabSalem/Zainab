from PyQt5 import QtCore, QtGui, QtWidgets
import MySQLdb as mdb 
import unittest
import Page8


class TestPage7(unittest.TestCase):
    
    # Test checkboxes and pushbuttons
    def test_setupUi(self):
        # Identify the test values 
        SitToNineHours  = self.SitToNineHours = QtWidgets.QRadioButton
        LessThanSixHours = LessThanSixHours = QtWidgets.QRadioButton
        IDontKnow = self.IDontKnow = QtWidgets.QRadioButton
        Continue = self.Continue = QtWidgets.QPushButton
        Back = self.Back = QtWidgets.QPushButton
        checkBoxes = SitToNineHours,LessThanSixHours,IDontKnow
        Pushbuttons = Continue, Back
        self.assertTrue(checkBoxes,Pushbuttons) #Tests the values
    
   
    # Test connection to Database and inserted data to database
    def test_DB(self):
        # Identify test values
        SitToNineHours  = self.SitToNineHours = QtWidgets.QRadioButton
        LessThanSixHours = LessThanSixHours = QtWidgets.QRadioButton
        IDontKnow = self.IDontKnow = QtWidgets.QRadioButton
        
        sql = (  
        "INSERT INTO question6(SitToNineHours ,LessThanSixHours, IDontKnow)"
        "VALUES (%s, %s, %s)"
        )
        data = (SitToNineHours,LessThanSixHours, IDontKnow)
       
        TestConnection = connection = mdb.connect("localhost","root","root","coolmind")
        cursor = connection.cursor() # object
        TestInsertedData= cursor.execute(sql, data)
        self.assertTrue(TestConnection, TestInsertedData)

        
if __name__ == '__main__':
        unittest.main()      
        