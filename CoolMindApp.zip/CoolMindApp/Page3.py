from PyQt5 import QtCore, QtGui, QtWidgets
from Page4 import Ui_Page4
import MySQLdb as mdb 


class Ui_Page3(object):
    
    def Page4(self): #Method to connect page4
        self.window2 = QtWidgets.QMainWindow()
        self.ui = Ui_Page4()
        self.ui.setupUi(self.window2)
        self.window2.show()
        
    def DB(self):  # Method that connects with database and saves the data
        
        try: #checks if database is connected 
            connection = mdb.connect("localhost","root","root","coolmind")
            cursor = connection.cursor() # object
            print("Your are connected to Database")
            
            cursor = connection.cursor()
        except Exception as e:
            print("Database not connected")
        # declaire the checkboxes into variables 
        Stress = self.Stress.isChecked()
        Concern = self.Concern.isChecked() 
        Anxiety = self.Anxiety.isChecked()
        depression= self.depression.isChecked()
        
        #collect all checkbox variables into variable "data"
        data = (Stress, Concern ,Anxiety, depression)
        
        #SQL query that inserts data to table question1 in MYSQL
        sql = (  
        "INSERT INTO question1(stress, concern ,anxiety, depression)"
        "VALUES (%s, %s, %s,%s)"
        )
              
        try: # checks if data is inserted
            cursor.execute(sql, data)
            connection.commit()
        except:
            connection.rollback()
            print("Data inserted")
            connection.close()   
   
    #Method for the page layout
    def setupUi(self, Page3):
        Page3.setObjectName("Page3")
        Page3.resize(480, 601)
        self.centralwidget = QtWidgets.QWidget(Page3)
        self.centralwidget.setObjectName("centralwidget")
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(-240, -10, 991, 861))
        self.label.setStyleSheet("image: url(:/newPrefix/blue sky.jpg);")
        self.label.setText("")
        self.label.setObjectName("label")
        self.label_2 = QtWidgets.QLabel(self.centralwidget)
        self.label_2.setGeometry(QtCore.QRect(10, 30, 171, 71))
        self.label_2.setStyleSheet("font: 75 20pt \"MS Shell Dlg 2\";\n"
"font: 22pt \"MS Shell Dlg 2\";\n"
"font: 75 26pt \"MS Shell Dlg 2\";\n"
"font: 75 22pt \"MS Shell Dlg 2\";")
        self.label_2.setObjectName("label_2")
        self.label_3 = QtWidgets.QLabel(self.centralwidget)
        self.label_3.setGeometry(QtCore.QRect(10, 100, 301, 31))
        self.label_3.setStyleSheet("font: 75 14pt \"MS Shell Dlg 2\";")
        self.label_3.setObjectName("label_3")
        self.label_5 = QtWidgets.QLabel(self.centralwidget)
        self.label_5.setGeometry(QtCore.QRect(20, 150, 191, 41))
        self.label_5.setStyleSheet("font: 75 14pt \"MS Shell Dlg 2\";")
        self.label_5.setObjectName("label_5")
        self.label_6 = QtWidgets.QLabel(self.centralwidget)
        self.label_6.setGeometry(QtCore.QRect(20, 210, 191, 41))
        self.label_6.setStyleSheet("font: 75 14pt \"MS Shell Dlg 2\";")
        self.label_6.setObjectName("label_6")
        self.label_7 = QtWidgets.QLabel(self.centralwidget)
        self.label_7.setGeometry(QtCore.QRect(20, 290, 191, 41))
        self.label_7.setStyleSheet("font: 75 14pt \"MS Shell Dlg 2\";")
        self.label_7.setObjectName("label_7")
        self.label_8 = QtWidgets.QLabel(self.centralwidget)
        self.label_8.setGeometry(QtCore.QRect(20, 360, 191, 41))
        self.label_8.setStyleSheet("font: 75 14pt \"MS Shell Dlg 2\";")
        self.label_8.setObjectName("label_8")
        # CheckBox stress
        self.Stress = QtWidgets.QCheckBox(self.centralwidget)
        self.Stress.setGeometry(QtCore.QRect(210, 160, 20, 21))
        self.Stress.setText("")
        self.Stress.setObjectName("Stress")
        #Checkbox concern
        self.Concern = QtWidgets.QCheckBox(self.centralwidget)
        self.Concern.setGeometry(QtCore.QRect(210, 220, 20, 21))
        self.Concern.setText("")
        self.Concern.setObjectName("Concern")
        
        #checkBox anxiety
        self.Anxiety = QtWidgets.QCheckBox(self.centralwidget)
        self.Anxiety.setGeometry(QtCore.QRect(210, 300, 20, 21))
        self.Anxiety.setText("")
        self.Anxiety.setObjectName("Anxiety")
        
        #checkbox depression 
        self.depression = QtWidgets.QCheckBox(self.centralwidget)
        self.depression.setGeometry(QtCore.QRect(210, 370, 20, 21))
        self.depression.setText("")
        self.depression.setObjectName("depression")
        
        # Pushbutton "continue"
        self.pushButton = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton.setGeometry(QtCore.QRect(170, 430, 141, 61))
        self.pushButton.setStyleSheet("font: 75 16pt \"MS Shell Dlg 2\";\n"
"font: 14pt \"MS Shell Dlg 2\";\n"
"font: 16pt \"MS Shell Dlg 2\";\n"
"font: 14pt \"MS Shell Dlg 2\";")
        self.pushButton.setObjectName("pushButton")
        
        self.pushButton.clicked.connect(self.Page4) # connects to page4
        self.pushButton.clicked.connect(Page3.close) #closes page3
        self.pushButton.clicked.connect(self.DB) #connects to database, calls DB method
        
        Page3.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(Page3)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 480, 26))
        self.menubar.setObjectName("menubar")
        Page3.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(Page3)
        self.statusbar.setObjectName("statusbar")
        Page3.setStatusBar(self.statusbar)

        self.retranslateUi(Page3)
        QtCore.QMetaObject.connectSlotsByName(Page3)

    def retranslateUi(self, Page3):
        _translate = QtCore.QCoreApplication.translate
        Page3.setWindowTitle(_translate("Page3", "MainWindow"))
        self.label_2.setText(_translate("Page3", "<font color = white>Welcome"))
        self.label_3.setText(_translate("Page3", "1.How are you feeling today?"))
        self.label_5.setText(_translate("Page3", "<html><head/><body><p><span style=\" font-weight:600; color:#ffffff;\">1. Stress</span></p></body></html>"))
        self.label_6.setText(_translate("Page3", "<html><head/><body><p><span style=\" font-weight:600; color:#ffffff;\">2. Concern</span></p></body></html>"))
        self.label_7.setText(_translate("Page3", "<html><head/><body><p><span style=\" font-weight:600; color:#ffffff;\">3. Anxiety</span></p></body></html>"))
        self.label_8.setText(_translate("Page3", "<html><head/><body><p><span style=\" font-weight:600; color:#ffffff;\">4. Depression</span></p></body></html>"))
        self.pushButton.setText(_translate("Page3", "Continue"))
import source2


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Page3 = QtWidgets.QMainWindow()
    ui = Ui_Page3()
    ui.setupUi(Page3)
    Page3.show()
    sys.exit(app.exec_())
