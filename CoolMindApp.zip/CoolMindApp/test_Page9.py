from PyQt5 import QtCore, QtGui, QtWidgets
import MySQLdb as mdb 
import unittest
import Page9


class TestPage9(unittest.TestCase):
    
    # Test checkboxes "1,2,3,4" and pushbuttons "continue, back"
    def test_setupUi(self):
        # Identify the test values 
        ONE = self.ONE = QtWidgets.QRadioButton
        TWO = self.TWO = QtWidgets.QRadioButton
        THREE = self.THREE = QtWidgets.QRadioButton
        FOUR = self.FOUR = QtWidgets.QRadioButton
        Back = self.Back = QtWidgets.QPushButton
        Continue = self.Continue_2 = QtWidgets.QPushButton
        test_values = ONE, TWO,THREE, FOUR
        pushButtons = Back, Continue
        self.assertTrue(test_values, pushButtons) #Tests the values

    
    # Test connection to Database and inserted data to database
    def test_DB(self):
        # Identify test values
        ONE = self.ONE = QtWidgets.QRadioButton
        TWO = self.TWO = QtWidgets.QRadioButton
        THREE = self.THREE = QtWidgets.QRadioButton
        FOUR = self.FOUR = QtWidgets.QRadioButton
        
        sql = (  
        "INSERT INTO question7(ONE ,TWO, THREE,FOUR)"
        "VALUES (%s, %s, %s,%s)"
        )
        data = (ONE,TWO, THREE,FOUR)
       
        TestConnection = connection = mdb.connect("localhost","root","root","coolmind")
        cursor = connection.cursor() # object
        TestInsertedData= cursor.execute(sql, data)
        self.assertTrue(TestConnection, TestInsertedData)

        
if __name__ == '__main__':
        unittest.main()      
        