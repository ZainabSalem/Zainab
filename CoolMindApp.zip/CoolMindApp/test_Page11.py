from PyQt5 import QtCore, QtGui, QtWidgets
import MySQLdb as mdb 
import unittest
import Page10


class TestPage10(unittest.TestCase):
    
    # Test checkboxes "Yes,No" and pushbuttons "continue, back"
    def test_setupUi(self):
        # Identify the test values 
        YES = self.YES = QtWidgets.QRadioButton
        NO =  self.NO = QtWidgets.QRadioButton
        Back = self.Back = QtWidgets.QPushButton
        Continue = self.Continue_2 = QtWidgets.QPushButton
        test_values = YES, NO
        pushButtons = Back, Continue
        self.assertTrue(test_values, pushButtons) #Tests the values

    
    # Test connection to Database and inserted data to database
    def test_DB(self):
        # Identify test values
        YES = self.YES = QtWidgets.QRadioButton
        NO =  self.NO = QtWidgets.QRadioButton
        
        sql = (  
        "INSERT INTO question9(YES, NO)"
        "VALUES (%s, %s)"
        )
        
        data = (YES,NO)
       
        TestConnection = connection = mdb.connect("localhost","root","root","coolmind")
        cursor = connection.cursor() # object
        TestInsertedData= cursor.execute(sql, data)
        self.assertTrue(TestConnection, TestInsertedData)

        
if __name__ == '__main__':
        unittest.main()      
        