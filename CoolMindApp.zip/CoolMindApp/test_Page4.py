from PyQt5 import QtCore, QtGui, QtWidgets
import MySQLdb as mdb 
import unittest
import Page3
import Page4


class TestPage4(unittest.TestCase):
    
    # Test checkboxes "once a Week" and "twice a week"
    def test_setupUi(self):
        # Identify the test values 
        onceAweek = self.OnceAWeek = QtWidgets.QRadioButton
        twiceAweek = self.TwiceAWeek = QtWidgets.QRadioButton
        self.assertTrue(onceAweek,twiceAweek) #Tests the values
    
    # Test checkboxes " I don´t know" and "Continue"
    def test__setupUi(self):
        iDontknow = self.IDontKnow = QtWidgets.QRadioButton
        Continue = self.Continue = QtWidgets.QPushButton
        
        self.assertTrue(iDontknow,Continue) #Tests the values if its true that they work, test will pass
    
    #Test "back" button   
    def test___setupUi(self):
        Back = self.Back = QtWidgets.QPushButton
        self.assertTrue(Back) #Tests the values if its true that they work, test will pass
        
    # Test connection to Database and inserted data to database
    def test_DB(self):
        onceAweek = self.OnceAWeek = QtWidgets.QRadioButton
        twiceAweek = self.TwiceAWeek = QtWidgets.QRadioButton
        iDontknow = self.IDontKnow = QtWidgets.QRadioButton
        
        sql = (  
        "INSERT INTO question2(onceAweek, twiceAweek,iDontknow)"
        "VALUES (%s, %s, %s)"
        )
        data = (onceAweek, twiceAweek,iDontknow)
       
        TestConnection = connection = mdb.connect("localhost","root","root","coolmind")
        cursor = connection.cursor() # object
        TestInsertedData= cursor.execute(sql, data)
        self.assertTrue(TestConnection, TestInsertedData)

        
if __name__ == '__main__':
        unittest.main()      
        