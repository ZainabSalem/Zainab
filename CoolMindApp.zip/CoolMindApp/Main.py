
from PyQt5 import QtCore, QtGui, QtWidgets
from Page1 import Ui_Page1


def run_the_app(self):
    setupUi(self, Page1)


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Page1 = QtWidgets.QMainWindow()
    ui = Ui_Page1()
    ui.setupUi(Page1)
    Page1.show()
    sys.exit(app.exec_())



