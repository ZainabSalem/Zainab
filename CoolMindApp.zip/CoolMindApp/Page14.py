
from PyQt5 import QtCore, QtGui, QtWidgets
import MySQLdb as mdb

class Ui_Page14(object):
    def DB(self):  # Method that connects with database and saves the data
        
        try: #checks if database is connected 
            connection = mdb.connect("localhost","root","root","coolmind")
            cursor = connection.cursor() # object
            print("Your are connected to Database")
            
            cursor = connection.cursor()
        except Exception as e:
            print("Database not connected")
        # declaire the checkboxes into variables 
        YES= self.YES.isChecked()
        NO = self.NO.isChecked() 
        YES_TEXT = self.YES_TEXT.toPlainText()

        
        
        #collect all checkbox variables into variable "data"
        data = (YES,NO, YES_TEXT)
        
        #SQL query that inserts data to table question1 in MYSQL
        sql = (  
        "INSERT INTO question11(YES,NO, YES_TEXT)"
        "VALUES (%s, %s, %s)"
        )
              
        try: # checks if data is inserted
            cursor.execute(sql, data)
            connection.commit()
        except:
            connection.rollback()
            print("Data inserted")
            connection.close()   
    
    def Page13(self): # import and identify page13
        from Page13 import Ui_Page13
        self.window2 = QtWidgets.QMainWindow()
        self.ui = Ui_Page13()
        self.ui.setupUi(self.window2)
        self.window2.show()
    
  
    def Page15(self): #import and identify page15
        from Page15 import Ui_Page15
        self.window2 = QtWidgets.QMainWindow()
        self.ui = Ui_Page15()
        self.ui.setupUi(self.window2)
        self.window2.show()
    
    def setupUi(self, Page14):
        Page14.setObjectName("Page14")
        Page14.resize(504, 614)
        self.centralwidget = QtWidgets.QWidget(Page14)
        self.centralwidget.setObjectName("centralwidget")
         # bluesky picture
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(-330, -80, 1191, 931))
        self.label.setStyleSheet("image: url(:/newPrefix/blue sky.jpg);")
        self.label.setText("")
        self.label.setObjectName("label")
        # question text
        self.label_6 = QtWidgets.QLabel(self.centralwidget)
        self.label_6.setGeometry(QtCore.QRect(20, 70, 581, 81))
        self.label_6.setStyleSheet("font: 75 14pt \"MS Shell Dlg 2\";\n"
"font: 75 14pt \"MS Shell Dlg 2\";")
        self.label_6.setObjectName("label_6")
        # NO text
        self.label_7 = QtWidgets.QLabel(self.centralwidget)
        self.label_7.setGeometry(QtCore.QRect(20, 160, 61, 41))
        self.label_7.setStyleSheet("font: 75 14pt \"MS Shell Dlg 2\";")
        self.label_7.setObjectName("label_7")
        # "If yes then type here" text
        self.label_8 = QtWidgets.QLabel(self.centralwidget)
        self.label_8.setGeometry(QtCore.QRect(20, 260, 271, 41))
        self.label_8.setStyleSheet("font: 75 14pt \"MS Shell Dlg 2\";")
        self.label_8.setObjectName("label_8")
        # continue button
        self.Continue_5 = QtWidgets.QPushButton(self.centralwidget)
        self.Continue_5.setGeometry(QtCore.QRect(270, 470, 141, 61))
        self.Continue_5.setStyleSheet("font: 75 16pt \"MS Shell Dlg 2\";\n"
"font: 14pt \"MS Shell Dlg 2\";\n"
"font: 16pt \"MS Shell Dlg 2\";\n"
"font: 14pt \"MS Shell Dlg 2\";")
        self.Continue_5.setObjectName("Continue_5")
        self.Continue_5.clicked.connect(self.Page15)
        self.Continue_5 .clicked.connect(Page14.close)
        self.Continue_5 .clicked.connect(self.DB)

        # back button
        self.Back = QtWidgets.QPushButton(self.centralwidget)
        self.Back.setGeometry(QtCore.QRect(90, 470, 141, 61))
        self.Back.setStyleSheet("font: 75 16pt \"MS Shell Dlg 2\";\n"
"font: 14pt \"MS Shell Dlg 2\";\n"
"font: 16pt \"MS Shell Dlg 2\";\n"
"font: 14pt \"MS Shell Dlg 2\";")
        self.Back.setObjectName("Back")
        self.Back.clicked.connect(self.Page13)
        self.Back.clicked.connect(Page14.close)
        # checkbox for NO
        self.NO = QtWidgets.QRadioButton(self.centralwidget)
        self.NO.setGeometry(QtCore.QRect(90, 170, 95, 20))
        self.NO.setText("")
        self.NO.setObjectName("NO")
        # YES text
        self.label_9 = QtWidgets.QLabel(self.centralwidget)
        self.label_9.setGeometry(QtCore.QRect(20, 210, 61, 41))
        self.label_9.setStyleSheet("font: 75 14pt \"MS Shell Dlg 2\";")
        self.label_9.setObjectName("label_9")
        # CheckBox for YES
        self.YES = QtWidgets.QRadioButton(self.centralwidget)
        self.YES.setGeometry(QtCore.QRect(90, 220, 95, 20))
        self.YES.setText("")
        self.YES.setObjectName("YES")
        # Textbox for user to write freely
        self.YES_TEXT = QtWidgets.QPlainTextEdit(self.centralwidget)
        self.YES_TEXT.setGeometry(QtCore.QRect(20, 300, 391, 161))
        self.YES_TEXT.setObjectName("YES_TEXT")
        
        Page14.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(Page14)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 504, 26))
        self.menubar.setObjectName("menubar")
        Page14.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(Page14)
        self.statusbar.setObjectName("statusbar")
        Page14.setStatusBar(self.statusbar)

        self.retranslateUi(Page14)
        QtCore.QMetaObject.connectSlotsByName(Page14)

    def retranslateUi(self, Page14):
        _translate = QtCore.QCoreApplication.translate
        Page14.setWindowTitle(_translate("Page14", "MainWindow"))
        self.label_6.setText(_translate("Page14", "<html><head/><body><p>Is there anything else you would like<br/>us to know?</p></body></html>"))
        self.label_7.setText(_translate("Page14", "<html><head/><body><p><span style=\" font-weight:600; color:#ffffff;\">No</span></p></body></html>"))
        self.label_8.setText(_translate("Page14", "<html><head/><body><p><span style=\" font-weight:600; color:#ffffff;\">If yes, then type here:</span></p></body></html>"))
        self.Continue_5.setText(_translate("Page14", "Continue"))
        self.Back.setText(_translate("Page14", "Back"))
        self.label_9.setText(_translate("Page14", "<html><head/><body><p><span style=\" font-weight:600; color:#ffffff;\">Yes</span></p></body></html>"))
import source14


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Page14 = QtWidgets.QMainWindow()
    ui = Ui_Page14()
    ui.setupUi(Page14)
    Page14.show()
    sys.exit(app.exec_())
