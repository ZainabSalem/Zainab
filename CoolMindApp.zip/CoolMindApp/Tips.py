from PyQt5 import QtCore, QtGui, QtWidgets
import MySQLdb as mdb
from Page12 import Ui_Page12
from Page3 import Ui_Page3
from Page15 import Ui_Page15


class Ui_Tips(object):
    
    
    def textTips(self):
        from textTips import textTips
        self.window2 = QtWidgets.QMainWindow()
        self.ui = Ui_Tips()
        self.ui.setupUi(self.window2)
    
    tip_of_the_day = ''   
      
    def DB(self): # method that connects to database and fetches data
        try: #checks if database is connected 
            connection = mdb.connect("localhost","root","root","coolmind")
            cursor = connection.cursor() # object
            print("Your are connected to Database")
            
            cursor = connection.cursor()
        except Exception as e:
            print("Database not connected")
            
      
    # fetch saved data from MYSQL Page3 and Page12
        cursor.execute(  
                "SELECT * FROM question_10 ORDER BY id DESC LIMIT 1;"
            )
        
        result = cursor.fetchall()
        data_question10 = result [0]
        print("answer to question 10 = ", data_question10) # prints out data from MYSQL to terminal as a tuple
            
        print("")
        
        cursor.execute (  
                "SELECT * FROM question1 ORDER BY id DESC LIMIT 1;"
            )
        
        result = cursor.fetchall()
        data_question1 = result [0]
        print ("answer to question 1 = ", data_question1)
            
     
        if data_question10[2] or [3] == "1": # if checkbox "tips" and "Both" is TRUE(1) 
            
            if data_question1 [0] == "1": # if checkbox stress is TRUE "1"
                # then fetch stress tip fron MYSQL 
                sql = (  
                "SELECT * FROM stress_tip ORDER BY id DESC LIMIT 1;"
            )
                cursor.execute(sql)
                result = cursor.fetchall()
                self.tip_of_the_day = result[0][1]  # prints the tip to the user
                

            if data_question1 [1] == "1":
                # then fetch concern tip from MYSQL
                sql =  (  
                "SELECT * FROM concern_tip ORDER BY id DESC LIMIT 1;" #Fetch data from concern_tip table and order the data by id in decending order to fetch the last inserted row in concern_tip table
            )
                cursor.execute(sql)
                result = cursor.fetchall()
                self.tip_of_the_day = result[0][1]  # prints the tip to the user
                
                
                
            if data_question1 [2] == "1":
                # then fetch anxiety tip from MYSQL
                sql= (  
                "SELECT * FROM anxiety_tip ORDER BY id DESC LIMIT 1;"
            )
                cursor.execute(sql)
                result = cursor.fetchall()
                self.tip_of_the_day = result[0][1]  # prints the tip to the user
                
                 
            if data_question1 [3] == "1":
                #then fetch depression tip from MYSQL
                sql= (  
                "SELECT * FROM depression_tip ORDER BY id DESC LIMIT 1;"
            )
                cursor.execute(sql)
                result = cursor.fetchall()
                self.tip_of_the_day = result[0][1]   # prints the tip to the user
         
        
       
           
    def setupUi(self, Tips):
        self.DB()
        Tips.setObjectName("Tips")
        Tips.resize(501, 613)
        self.centralwidget = QtWidgets.QWidget(Tips)
        self.centralwidget.setObjectName("centralwidget")
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(-530, -70, 1581, 911))
        self.label.setStyleSheet("image: url(:/newPrefix/blue sky.jpg);")
        self.label.setText("")
        self.label.setObjectName("label")

        self.label_4 = QtWidgets.QLabel(self.centralwidget)
        self.label_4.setGeometry(QtCore.QRect(40, 70, 301, 31))
        self.label_4.setStyleSheet("font: 75 14pt \"MS Shell Dlg 2\";")
        self.label_4.setObjectName("label_4")
        
        self.tip_text = QtWidgets.QLabel(self.centralwidget)
        self.tip_text.setGeometry(QtCore.QRect(100, 120, 400, 300))
        self.tip_text.setStyleSheet("font: 75 14pt \"MS Shell Dlg 2\";")
        self.tip_text.setObjectName("tip_text")
        self.tip_text.setWordWrap(True)
        self.tip_text.setText(self.tip_of_the_day)

        Tips.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(Tips)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 501, 26))
        self.menubar.setObjectName("menubar")
        Tips.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(Tips)
        self.statusbar.setObjectName("statusbar")
        Tips.setStatusBar(self.statusbar)

        self.retranslateUi(Tips)
        QtCore.QMetaObject.connectSlotsByName(Tips)
    
    
    def resizeEvent(self, event):
        _translate = QtCore.QCoreApplication.translate        
        print(event)
    
    
    def retranslateUi(self, Tips):
        _translate = QtCore.QCoreApplication.translate
        Tips.setWindowTitle(_translate("Tips", "MainWindow"))
        self.label_4.setText(_translate("Tips", "Tip of the day:"))
import Tips_source



if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Tips = QtWidgets.QMainWindow()
    ui = Ui_Tips()
    ui.setupUi(Tips)
    Tips.show()
    sys.exit(app.exec_())
