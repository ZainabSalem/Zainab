
from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_Tips(object):
    
    def textTips(self):
        from textTips import textTips
        self.window2 = QtWidgets.QMainWindow()
        self.ui = Ui_Tips()
        self.ui.setupUi(self.window2)
        
    
    def setupUi(self, Tips):
        Tips.setObjectName("Tips")
        Tips.resize(501, 613)
        self.centralwidget = QtWidgets.QWidget(Tips)
        self.centralwidget.setObjectName("centralwidget")
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(-530, -70, 1581, 911))
        self.label.setStyleSheet("image: url(:/newPrefix/blue sky.jpg);")
        self.label.setText("")
        self.label.setObjectName("label")
        self.label_4 = QtWidgets.QLabel(self.centralwidget)
        self.label_4.setGeometry(QtCore.QRect(40, 70, 301, 31))
        self.label_4.setStyleSheet("font: 75 14pt \"MS Shell Dlg 2\";")
        self.label_4.setObjectName("label_4")
        Tips.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(Tips)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 501, 26))
        self.menubar.setObjectName("menubar")
        Tips.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(Tips)
        self.statusbar.setObjectName("statusbar")
        Tips.setStatusBar(self.statusbar)

        self.retranslateUi(Tips)
        QtCore.QMetaObject.connectSlotsByName(Tips)

    def retranslateUi(self, Tips):
        _translate = QtCore.QCoreApplication.translate
        Tips.setWindowTitle(_translate("Tips", "MainWindow"))
        self.label_4.setText(_translate("Tips", "Here is your tips:"))
import Tips_source



if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Tips = QtWidgets.QMainWindow()
    ui = Ui_Tips()
    ui.setupUi(Tips)
    Tips.show()
    sys.exit(app.exec_())
