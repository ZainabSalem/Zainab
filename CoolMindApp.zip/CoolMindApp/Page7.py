from PyQt5 import QtCore, QtGui, QtWidgets
import MySQLdb as mdb

class Ui_Page7(object):
    def DB(self):  # Method that connects with database and saves the data
        
        try: #checks if database is connected 
            connection = mdb.connect("localhost","root","root","coolmind")
            cursor = connection.cursor() # object
            print("Your are connected to Database")
            
            cursor = connection.cursor()
        except Exception as e:
            print("Database not connected")
        # declaire the checkboxes into variables 
        Today = self.Today.isChecked()
        AFewDaysAgo = self.AFewDaysAgo.isChecked() 
        IDontKnow = self.IDontKnow.isChecked()
        
        #collect all checkbox variables into variable "data"
        data = (Today ,AFewDaysAgo, IDontKnow)
        
        #SQL query that inserts data to table question1 in MYSQL
        sql = (  
        "INSERT INTO question5(Today ,AFewDaysAgo, IDontKnow)"
        "VALUES (%s, %s, %s)"
        )
              
        try: # checks if data is inserted
            cursor.execute(sql, data)
            connection.commit()
        except:
            connection.rollback()
            print("Data inserted")
            connection.close()   
    
    
    def Page8(self): #import and identify page8
        from Page8 import Ui_Page8
        self.window2 = QtWidgets.QMainWindow()
        self.ui = Ui_Page8()
        self.ui.setupUi(self.window2)
        self.window2.show()
        
        
    #Link back to page 6
    def Page6(self): 
        from Page6 import Ui_Page6
        self.window2 = QtWidgets.QMainWindow()
        self.ui = Ui_Page6()
        self.ui.setupUi(self.window2)
        self.window2.show()
    
    def setupUi(self, Page7):
        Page7.setObjectName("Page7")
        Page7.resize(499, 608)
        self.centralwidget = QtWidgets.QWidget(Page7)
        self.centralwidget.setObjectName("centralwidget")
        # blue sky picture
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(-20, -510, 761, 1201))
        self.label.setStyleSheet("background-image: url(:/newPrefix/bluesky.jpg);")
        self.label.setText("")
        self.label.setObjectName("label")
        self.label_2 = QtWidgets.QLabel(self.centralwidget)
        self.label_2.setGeometry(QtCore.QRect(-300, -50, 1131, 921))
        self.label_2.setStyleSheet("image: url(:/newPrefix/blue sky.jpg);")
        self.label_2.setText("")
        self.label_2.setObjectName("label_2")
         # "When did you eat properly, (three times in a day) with snacks in between the meals?" text
        self.label_8 = QtWidgets.QLabel(self.centralwidget)
        self.label_8.setGeometry(QtCore.QRect(20, 40, 331, 111))
        self.label_8.setStyleSheet("font: 75 14pt \"MS Shell Dlg 2\";")
        self.label_8.setObjectName("label_8")
        # "Today" text
        self.label_9 = QtWidgets.QLabel(self.centralwidget)
        self.label_9.setGeometry(QtCore.QRect(20, 170, 191, 41))
        self.label_9.setStyleSheet("font: 75 14pt \"MS Shell Dlg 2\";")
        self.label_9.setObjectName("label_9")
        # " A few days ago" text 
        self.label_10 = QtWidgets.QLabel(self.centralwidget)
        self.label_10.setGeometry(QtCore.QRect(20, 250, 191, 41))
        self.label_10.setStyleSheet("font: 75 14pt \"MS Shell Dlg 2\";")
        self.label_10.setObjectName("label_10")
        # "I dont know" text
        self.label_11 = QtWidgets.QLabel(self.centralwidget)
        self.label_11.setGeometry(QtCore.QRect(20, 320, 191, 41))
        self.label_11.setStyleSheet("font: 75 14pt \"MS Shell Dlg 2\";")
        self.label_11.setObjectName("label_11")
        # Continue button
        self.Continue = QtWidgets.QPushButton(self.centralwidget)
        self.Continue.setGeometry(QtCore.QRect(260, 450, 141, 61))
        self.Continue.setStyleSheet("font: 75 16pt \"MS Shell Dlg 2\";\n"
"font: 14pt \"MS Shell Dlg 2\";\n"
"font: 16pt \"MS Shell Dlg 2\";\n"
"font: 14pt \"MS Shell Dlg 2\";")
        self.Continue.setObjectName("Continue")
        
        self.Continue.clicked.connect(self.Page8) #connects page8
        self.Continue.clicked.connect(Page7.close) #closes page7
        self.Continue.clicked.connect(self.DB) # Calls method and connects ti database
        # back button 
        self.Back = QtWidgets.QPushButton(self.centralwidget)
        self.Back.setGeometry(QtCore.QRect(80, 450, 141, 61))
        self.Back.setStyleSheet("font: 75 16pt \"MS Shell Dlg 2\";\n"
"font: 14pt \"MS Shell Dlg 2\";\n"
"font: 16pt \"MS Shell Dlg 2\";\n"
"font: 14pt \"MS Shell Dlg 2\";")
        self.Back.setObjectName("Back")
        self.Back.clicked.connect(self.Page6) # goes back to Page6 when user clicks back 
        self.Back.clicked.connect(Page7.close) # page7 closes when user clicks back
        # checkbox for "Today"
        self.Today = QtWidgets.QRadioButton(self.centralwidget)
        self.Today.setGeometry(QtCore.QRect(240, 180, 95, 20))
        self.Today.setText("")
        self.Today.setObjectName("Today")
        # checkbox for "A few days ago"
        self.AFewDaysAgo = QtWidgets.QRadioButton(self.centralwidget)
        self.AFewDaysAgo.setGeometry(QtCore.QRect(240, 260, 95, 20))
        self.AFewDaysAgo.setText("")
        self.AFewDaysAgo.setObjectName("AFewDaysAgo")
        # checkbox for "I don´t know"
        self.IDontKnow = QtWidgets.QRadioButton(self.centralwidget)
        self.IDontKnow.setGeometry(QtCore.QRect(240, 330, 95, 20))
        self.IDontKnow.setText("")
        self.IDontKnow.setObjectName("IDontKnow")
        Page7.setCentralWidget(self.centralwidget)
        
        self.menubar = QtWidgets.QMenuBar(Page7)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 499, 26))
        self.menubar.setObjectName("menubar")
        Page7.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(Page7)
        self.statusbar.setObjectName("statusbar")
        Page7.setStatusBar(self.statusbar)

        self.retranslateUi(Page7)
        QtCore.QMetaObject.connectSlotsByName(Page7)

    def retranslateUi(self, Page7):
        _translate = QtCore.QCoreApplication.translate
        Page7.setWindowTitle(_translate("Page7", "MainWindow"))
        self.label_8.setText(_translate("Page7", "<html><head/><body><p>When did you eat properly,<br/>(three times in a day) <br/>with snacks in between the meals?</p></body></html>"))
        self.label_9.setText(_translate("Page7", "<html><head/><body><p><span style=\" font-weight:600; color:#ffffff;\">Today</span></p></body></html>"))
        self.label_10.setText(_translate("Page7", "<html><head/><body><p><span style=\" font-weight:600; color:#ffffff;\">A few days ago</span></p></body></html>"))
        self.label_11.setText(_translate("Page7", "<html><head/><body><p><span style=\" font-weight:600; color:#ffffff;\">I don´t know</span></p></body></html>"))
        self.Continue.setText(_translate("Page7", "Continue"))
        self.Back.setText(_translate("Page7", "Back"))
import source7


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Page7 = QtWidgets.QMainWindow()
    ui = Ui_Page7()
    ui.setupUi(Page7)
    Page7.show()
    sys.exit(app.exec_())
