from PyQt5 import QtCore, QtGui, QtWidgets
import MySQLdb as mdb 
import unittest
import Page3
import Page4


class TestPage3(unittest.TestCase):
    
    # Test checkboxes stress and concern
    def test_setupUi(self):
        # Identify the test values 
        Stress = self.Stress = QtWidgets.QCheckBox
        Concern = self.Concern = QtWidgets.QCheckBox
        self.assertTrue(Stress, Concern) #Tests the values
    
    # Test checkboxes anxiety and depression
    def test__setupUi(self):
        Anxiety = self.Anxiety = QtWidgets.QCheckBox
        depression = self.depression = QtWidgets.QCheckBox
        self.assertTrue(Anxiety,depression) #Tests the values if its true that they work, test will pass
    
    #Test continue button   
    def test___setupUi(self):
        Continue = self.pushButton = QtWidgets.QPushButton
        self.assertTrue(Continue) #Tests the values if its true that they work, test will pass
        
    # Test connection to Database and inserted data to database
    def test_DB(self):
        Stress = self.Stress = QtWidgets.QCheckBox
        Concern = self.Concern = QtWidgets.QCheckBox
        Anxiety = self.Anxiety = QtWidgets.QCheckBox
        depression = self.depression = QtWidgets.QCheckBox
        
        sql = (  
        "INSERT INTO question1(stress, concern ,anxiety, depression)"
        "VALUES (%s, %s, %s,%s)"
        )
        data = (Stress, Concern, Anxiety,depression)
       
        TestConnection = connection = mdb.connect("localhost","root","root","coolmind")
        cursor = connection.cursor() # object
        TestInsertedData= cursor.execute(sql, data)
        self.assertTrue(TestConnection, TestInsertedData)

        
if __name__ == '__main__':
        unittest.main()      
        