from PyQt5 import QtCore, QtGui, QtWidgets
import MySQLdb as mdb 
import unittest
import Page2
import Page3


class TestPage2(unittest.TestCase):
    
    #Test if Page3 opens when Register is clicked 
    def test_setupUi(self):
        # Identify the test value "Register" button.
        Register = self.Register = QtWidgets.QPushButton
        self.assertTrue(Register) #Tests the button
       # If its true that Page3 opens when "Register" is clicked, the test will not fail
    
    def test_DB(self):
        fullname = self.FullName_text = QtWidgets.QLineEdit
        email = self.Email_text = QtWidgets.QLineEdit
        password = self.password_text = QtWidgets.QLineEdit
        
        sql = (
        "INSERT INTO account(fullname,email,password)"
        "VALUES (%s, %s, %s)"
        )
        data = (fullname, email, password)
        
        TestConnection = connection = mdb.connect("localhost","root","root","coolmind")
        cursor = connection.cursor() # object
        TestInsertedData= cursor.execute(sql, data)
        self.assertTrue(TestConnection, TestInsertedData)
 
 
        
if __name__ == '__main__':
        unittest.main()      
        