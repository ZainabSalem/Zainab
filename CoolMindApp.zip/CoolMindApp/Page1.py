
from PyQt5 import QtCore, QtGui, QtWidgets
from SignInPage import Ui_SignInPage
from Page2 import Ui_Page2
import MySQLdb as mdb 

class Ui_Page1(object):
        
        def SignInPage (self): # import and indetify signInPage
                self.window2 = QtWidgets.QMainWindow()
                self.ui = Ui_SignInPage()
                self.ui.setupUi(self.window2)
                self.window2.show()
        
        def Page2 (self): # import and identify Page2
                self.window3 = QtWidgets.QMainWindow()
                self.ui = Ui_Page2()
                self.ui.setupUi(self.window3)
                self.window3.show()
                
        
        def setupUi(self, Page1):
                Page1.setObjectName("Page1")
                Page1.resize(510, 538)
                self.centralwidget = QtWidgets.QWidget(Page1)
                self.centralwidget.setObjectName("centralwidget")
                self.label = QtWidgets.QLabel(self.centralwidget)
                self.label.setGeometry(QtCore.QRect(-410, 10, 1231, 1031))
                self.label.setMaximumSize(QtCore.QSize(1231, 1031))
                self.label.setStyleSheet("background-image: url(:/newPrefix/woman-in-swimming-pool-.jpg);\n"
        "font: 75 12pt \"MS Shell Dlg 2\";")
                self.label.setObjectName("label")
                self.frame = QtWidgets.QFrame(self.centralwidget)
                self.frame.setGeometry(QtCore.QRect(250, 120, 120, 80))
                self.frame.setFrameShape(QtWidgets.QFrame.StyledPanel)
                self.frame.setFrameShadow(QtWidgets.QFrame.Raised)
                self.frame.setObjectName("frame")
                self.label_2 = QtWidgets.QLabel(self.centralwidget)
                self.label_2.setGeometry(QtCore.QRect(-220, -210, 731, 911))
                self.label_2.setStyleSheet("image: url(:/newPrefix/pool.jpg);")
                self.label_2.setText("")
                self.label_2.setObjectName("label_2")
                self.label_6 = QtWidgets.QLabel(self.centralwidget)
                self.label_6.setGeometry(QtCore.QRect(10, 60, 311, 51))
                self.label_6.setStyleSheet("font: 75 14pt \"MS Shell Dlg 2\";")
                self.label_6.setObjectName("label_6")
                self.label_4 = QtWidgets.QLabel(self.centralwidget)
                self.label_4.setGeometry(QtCore.QRect(20, 10, 241, 51))
                self.label_4.setStyleSheet("font: 75 28pt \"MS Shell Dlg 2\";\n"
        "font: 20pt \"MS Shell Dlg 2\";")
                self.label_4.setObjectName("label_4")
                # logIn button
                self.LogIn = QtWidgets.QPushButton(self.centralwidget)
                self.LogIn.setGeometry(QtCore.QRect(190, 300, 121, 61))
                self.LogIn.setStyleSheet("font: 75 16pt \"MS Shell Dlg 2\";\n"
        "font: 75 14pt \"MS Shell Dlg 2\";")
                self.LogIn.setObjectName("LogIn")
                self.LogIn.clicked.connect(self.SignInPage)
                self.LogIn.clicked.connect(Page1.close)
                # sign up button
                self.SignUp = QtWidgets.QPushButton(self.centralwidget)
                self.SignUp.setGeometry(QtCore.QRect(190, 390, 121, 61))
                self.SignUp.setStyleSheet("font: 75 14pt \"MS Shell Dlg 2\";")
                self.SignUp.setObjectName("SignUp")
                self.SignUp.clicked.connect(self.Page2)
                self.SignUp.clicked.connect(Page1.close)                
                
                Page1.setCentralWidget(self.centralwidget)
                self.menubar = QtWidgets.QMenuBar(Page1)
                self.menubar.setGeometry(QtCore.QRect(0, 0, 510, 26))
                self.menubar.setObjectName("menubar")
                Page1.setMenuBar(self.menubar)
                self.statusbar = QtWidgets.QStatusBar(Page1)
                self.statusbar.setObjectName("statusbar")
                Page1.setStatusBar(self.statusbar)

                self.retranslateUi(Page1)
                QtCore.QMetaObject.connectSlotsByName(Page1)

        def retranslateUi(self, Page1):
                _translate = QtCore.QCoreApplication.translate
                Page1.setWindowTitle(_translate("Page1", "MainWindow"))
                self.label.setText(_translate("Page1", "<html><head/><body><p><span style=\" font-size:16pt; font-weight:600;\">Cool Mind</span></p><p><br/></p></body></html>"))
                self.label_6.setText(_translate("Page1", "<html><head/><body><p><span style=\" font-size:18pt; font-weight:600; color:#40e0d0;\">We are here for you</span></p></body></html>"))
                self.label_4.setText(_translate("Page1", "<html><head/><body><p><span style=\" font-size:26pt; font-weight:600; color:#ffffff;\">Cool Mind </span></p></body></html>"))
                self.LogIn.setText(_translate("Page1", "Login"))
                self.SignUp.setText(_translate("Page1", "Sign up"))
import source


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Page1 = QtWidgets.QMainWindow()
    ui = Ui_Page1()
    ui.setupUi(Page1)
    Page1.show()
    sys.exit(app.exec_())
