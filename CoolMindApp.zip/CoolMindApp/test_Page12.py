from typing import Container
from PyQt5 import QtCore, QtGui, QtWidgets
import MySQLdb as mdb 
import unittest
import Page12


class TestPage12(unittest.TestCase):
    
    # Test checkboxes "contacted,tips,both" and pushbuttons "continue, back"
    def test_setupUi(self):
        # Identify the test values 
        CONTACTED = self.CONTACTED = QtWidgets.QRadioButton
        TIPS = self.TIPS = QtWidgets.QRadioButton
        BOTH = self.BOTH = QtWidgets.QRadioButton
        Back = self.Back = QtWidgets.QPushButton
        Continue = self.Continue_3 = QtWidgets.QPushButton
        test_values = CONTACTED, TIPS, BOTH
        pushButtons = Back, Continue
        self.assertTrue(test_values, pushButtons) #Tests the values

    
    # Test connection to Database and inserted data to database
    def test_DB(self):
        # Identify test values
        CONTACTED = self.CONTACTED = QtWidgets.QRadioButton
        TIPS = self.TIPS = QtWidgets.QRadioButton
        BOTH = self.BOTH = QtWidgets.QRadioButton
        
        sql = (  
        "INSERT INTO question_10(`CONTACTED`, `TIPS`, `BOTH`)"
        "VALUES (%s, %s, %s)"
        ) 
        
        data = CONTACTED, BOTH, TIPS
       
        TestConnection = connection = mdb.connect("localhost","root","root","coolmind")
        cursor = connection.cursor() # object
        TestInsertedData= cursor.execute(sql, data)
        self.assertTrue(TestConnection, TestInsertedData)

        
if __name__ == '__main__':
        unittest.main()      
        