from PyQt5 import QtCore, QtGui, QtWidgets
import MySQLdb as mdb 
import unittest
import Page13


class TestPage10(unittest.TestCase):
    
    # Test checkboxes "back, continue" and pushbuttons "continue, back"
    def test_setupUi(self):
        # Identify the test values 
        Back = self.Back = QtWidgets.QPushButton
        Continue = self.Continue_4 = QtWidgets.QPushButton
        pushButtons = Back, Continue
        self.assertTrue(pushButtons) #Tests the values


        
if __name__ == '__main__':
        unittest.main()      
        