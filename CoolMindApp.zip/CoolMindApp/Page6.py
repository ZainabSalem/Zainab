
from PyQt5 import QtCore, QtGui, QtWidgets
import MySQLdb as mdb 

class Ui_Page6(object):
    
    def DB(self):  # Method that connects with database and saves the data
        
        try: #checks if database is connected 
            connection = mdb.connect("localhost","root","root","coolmind")
            cursor = connection.cursor() # object
            print("Your are connected to Database")
            
            cursor = connection.cursor()
        except Exception as e:
            print("Database not connected")
        # declaire the checkboxes into variables 
        onceAweek = self.OnceAWeek.isChecked()
        MoreThanOnceweek = self.MoreThanOnceWeek.isChecked() 
        NotAtAll = self.NotAtAll.isChecked()
        
        #collect all checkbox variables into variable "data"
        data = (onceAweek,MoreThanOnceweek,NotAtAll)
        
        #SQL query that inserts data to table question1 in MYSQL
        sql = (  
        "INSERT INTO question4(onceAweek,MoreThanOnceweek,NotAtAll)"
        "VALUES (%s, %s, %s)"
        )
              
        try: # checks if data is inserted
            cursor.execute(sql, data)
            connection.commit()
        except:
            connection.rollback()
            print("Data inserted")
            connection.close()   
        
    def Page7(self):  #import and identify page7
        from Page7 import Ui_Page7
        self.window2 = QtWidgets.QMainWindow()
        self.ui = Ui_Page7()
        self.ui.setupUi(self.window2)
        self.window2.show()
        
     
    def Page5(self):  #import and identify page5
        from Page5 import Ui_Page5
        self.window2 = QtWidgets.QMainWindow()
        self.ui = Ui_Page5()
        self.ui.setupUi(self.window2)
        self.window2.show()
    
   
    def setupUi(self, Page6):
        Page6.setObjectName("Page6")
        Page6.resize(500, 605)
        self.centralwidget = QtWidgets.QWidget(Page6)
        self.centralwidget.setObjectName("centralwidget")
        # blue sky picture
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(-20, -510, 611, 891))
        self.label.setStyleSheet("background-image: url(:/newPrefix/bluesky.jpg);")
        self.label.setText("")
        self.label.setObjectName("label")
        self.label_2 = QtWidgets.QLabel(self.centralwidget)
        self.label_2.setGeometry(QtCore.QRect(-350, -60, 1241, 911))
        self.label_2.setStyleSheet("image: url(:/newPrefix/blue sky.jpg);")
        self.label_2.setText("")
        self.label_2.setObjectName("label_2")
        # "once a week" text
        self.label_7 = QtWidgets.QLabel(self.centralwidget)
        self.label_7.setGeometry(QtCore.QRect(20, 170, 191, 41))
        self.label_7.setStyleSheet("font: 75 14pt \"MS Shell Dlg 2\";")
        self.label_7.setObjectName("label_7")
       # "More than once a week" text
        self.label_9 = QtWidgets.QLabel(self.centralwidget)
        self.label_9.setGeometry(QtCore.QRect(20, 230, 151, 71))
        self.label_9.setStyleSheet("font: 75 14pt \"MS Shell Dlg 2\";")
        self.label_9.setObjectName("label_9")
        # "Not at all" text 
        self.label_10 = QtWidgets.QLabel(self.centralwidget)
        self.label_10.setGeometry(QtCore.QRect(20, 310, 151, 71))
        self.label_10.setStyleSheet("font: 75 14pt \"MS Shell Dlg 2\";")
        self.label_10.setObjectName("label_10")
        # "How often do you participate in leisure activities you enjoy?" text
        self.label_5 = QtWidgets.QLabel(self.centralwidget)
        self.label_5.setGeometry(QtCore.QRect(10, 40, 581, 81))
        self.label_5.setStyleSheet("font: 75 14pt \"MS Shell Dlg 2\";\n"
"font: 75 14pt \"MS Shell Dlg 2\";")
        self.label_5.setObjectName("label_5")
        # continue button
        self.Continue = QtWidgets.QPushButton(self.centralwidget)
        self.Continue.setGeometry(QtCore.QRect(270, 450, 141, 61))
        self.Continue.setStyleSheet("font: 75 16pt \"MS Shell Dlg 2\";\n"
"font: 14pt \"MS Shell Dlg 2\";\n"
"font: 16pt \"MS Shell Dlg 2\";\n"
"font: 14pt \"MS Shell Dlg 2\";")
        self.Continue.setObjectName("Continue")
        self.Continue.clicked.connect(self.Page7) # connects to page7
        self.Continue.clicked.connect(Page6.close) # closes page6 
        self.Continue.clicked.connect(self.DB) # calls method DB that Connects to databse
        # back button
        self.Back = QtWidgets.QPushButton(self.centralwidget)
        self.Back.setGeometry(QtCore.QRect(90, 450, 141, 61))
        self.Back.setStyleSheet("font: 75 16pt \"MS Shell Dlg 2\";\n"
"font: 14pt \"MS Shell Dlg 2\";\n"
"font: 16pt \"MS Shell Dlg 2\";\n"
"font: 14pt \"MS Shell Dlg 2\";")
        
        self.Back.setObjectName("Back")
        self.Back.clicked.connect(self.Page5) 
        self.Back.clicked.connect(Page6.close)
        # Checkbox for "once a week"
        self.OnceAWeek = QtWidgets.QRadioButton(self.centralwidget)
        self.OnceAWeek.setGeometry(QtCore.QRect(190, 180, 95, 20))
        self.OnceAWeek.setText("")
        self.OnceAWeek.setObjectName("OnceAWeek")
        # checkbox for " More than once a week"
        self.MoreThanOnceWeek = QtWidgets.QRadioButton(self.centralwidget)
        self.MoreThanOnceWeek.setGeometry(QtCore.QRect(190, 250, 95, 20))
        self.MoreThanOnceWeek.setText("")
        self.MoreThanOnceWeek.setObjectName("MoreThanOnceWeek")
       # checkbox for "not at all"
        self.NotAtAll = QtWidgets.QRadioButton(self.centralwidget)
        self.NotAtAll.setGeometry(QtCore.QRect(190, 330, 95, 20))
        self.NotAtAll.setText("")
        self.NotAtAll.setObjectName("NotAtAll")
       
        Page6.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(Page6)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 500, 26))
        self.menubar.setObjectName("menubar")
        Page6.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(Page6)
        self.statusbar.setObjectName("statusbar")
        Page6.setStatusBar(self.statusbar)

        self.retranslateUi(Page6)
        QtCore.QMetaObject.connectSlotsByName(Page6)

    def retranslateUi(self, Page6):
        _translate = QtCore.QCoreApplication.translate
        Page6.setWindowTitle(_translate("Page6", "MainWindow"))
        self.label_7.setText(_translate("Page6", "<html><head/><body><p><span style=\" font-weight:600; color:#ffffff;\">Once a week</span></p></body></html>"))
        self.label_9.setText(_translate("Page6", "<html><head/><body><p><span style=\" font-weight:600; color:#ffffff;\">More than <br/>once week</span></p></body></html>"))
        self.label_10.setText(_translate("Page6", "<html><head/><body><p><span style=\" font-weight:600; color:#ffffff;\">Not at all</span></p></body></html>"))
        self.label_5.setText(_translate("Page6", "<html><head/><body><p>How often do you participate in leisure<br/>activities you enjoy?</p></body></html>"))
        self.Continue.setText(_translate("Page6", "Continue"))
        self.Back.setText(_translate("Page6", "Back"))
import source6


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Page6 = QtWidgets.QMainWindow()
    ui = Ui_Page6()
    ui.setupUi(Page6)
    Page6.show()
    sys.exit(app.exec_())
