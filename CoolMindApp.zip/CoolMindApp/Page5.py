from PyQt5 import QtCore, QtGui, QtWidgets
import MySQLdb as mdb 

class Ui_Page5(object):
    
    def DB(self):  # Method that connects with database and saves the data
        
        try: #checks if database is connected 
            connection = mdb.connect("localhost","root","root","coolmind")
            cursor = connection.cursor() # object
            print("Your are connected to Database")
            
            cursor = connection.cursor()
        except Exception as e:
            print("Database not connected")
        # declaire the checkboxes into variables 
        onceAweek = self.OnceAWeek.isChecked()
        MoreThanAweek = self.MoreThanAWeek.isChecked() 
        NotAtAll = self.NotAtAll.isChecked()
        
        #collect all checkbox variables into variable "data"
        data = (onceAweek,MoreThanAweek,NotAtAll)
        
        #SQL query that inserts data to table question1 in MYSQL
        sql = (  
        "INSERT INTO question3(onceAweek,MoreThanAweek,NotAtAll)"
        "VALUES (%s, %s, %s)"
        )
              
        try: # checks if data is inserted
            cursor.execute(sql, data)
            connection.commit()
        except:
            connection.rollback()
            print("Data inserted")
            connection.close()   
    
    def Page4(self): #import and identify page4
        from Page4 import Ui_Page4
        self.window2 = QtWidgets.QMainWindow()
        self.ui = Ui_Page4()
        self.ui.setupUi(self.window2)
        self.window2.show()
    
    #import and identify page6
    def Page6(self): 
        from Page6 import Ui_Page6
        self.window2 = QtWidgets.QMainWindow()
        self.ui = Ui_Page6()
        self.ui.setupUi(self.window2)
        self.window2.show()
    
    def setupUi(self, Page5):
        Page5.setObjectName("Page5")
        Page5.resize(498, 603)
        self.centralwidget = QtWidgets.QWidget(Page5)
        self.centralwidget.setObjectName("centralwidget")
        # blue sky picture
        self.label_2 = QtWidgets.QLabel(self.centralwidget)
        self.label_2.setGeometry(QtCore.QRect(-300, -10, 1161, 931))
        self.label_2.setStyleSheet("image: url(:/newPrefix/blue sky.jpg);")
        self.label_2.setText("")
        self.label_2.setObjectName("label_2")
        # "more than once week" text
        self.label_10 = QtWidgets.QLabel(self.centralwidget)
        self.label_10.setGeometry(QtCore.QRect(30, 230, 151, 71))
        self.label_10.setStyleSheet("font: 75 14pt \"MS Shell Dlg 2\";")
        self.label_10.setObjectName("label_10")
        # "Not at all" text
        self.label_11 = QtWidgets.QLabel(self.centralwidget)
        self.label_11.setGeometry(QtCore.QRect(30, 300, 151, 71))
        self.label_11.setStyleSheet("font: 75 14pt \"MS Shell Dlg 2\";")
        self.label_11.setObjectName("label_11")
        # "How often do you exercise" text
        self.label_12 = QtWidgets.QLabel(self.centralwidget)
        self.label_12.setGeometry(QtCore.QRect(30, 100, 331, 31))
        self.label_12.setStyleSheet("font: 75 14pt \"MS Shell Dlg 2\";")
        self.label_12.setObjectName("label_12")
        # "Once a week" text
        self.label_13 = QtWidgets.QLabel(self.centralwidget)
        self.label_13.setGeometry(QtCore.QRect(30, 170, 191, 41))
        self.label_13.setStyleSheet("font: 75 14pt \"MS Shell Dlg 2\";")
        self.label_13.setObjectName("label_13")
        # continue button
        self.Continue = QtWidgets.QPushButton(self.centralwidget)
        self.Continue.setGeometry(QtCore.QRect(260, 440, 141, 61))
        self.Continue.setStyleSheet("font: 75 16pt \"MS Shell Dlg 2\";\n"
"font: 14pt \"MS Shell Dlg 2\";\n"
"font: 16pt \"MS Shell Dlg 2\";\n"
"font: 14pt \"MS Shell Dlg 2\";")
        self.Continue.setObjectName("Continue")
        
        self.Continue.clicked.connect(self.Page6) #connect page6
        self.Continue.clicked.connect(Page5.close) #closes page5
        self.Continue.clicked.connect(self.DB) #Calls method and connects to database
        # Back button
        self.Back = QtWidgets.QPushButton(self.centralwidget)
        self.Back.setGeometry(QtCore.QRect(90, 440, 141, 61))
        self.Back.setStyleSheet("font: 75 16pt \"MS Shell Dlg 2\";\n"
"font: 14pt \"MS Shell Dlg 2\";\n"
"font: 16pt \"MS Shell Dlg 2\";\n"
"font: 14pt \"MS Shell Dlg 2\";")
        self.Back.setObjectName("Back")
        
        self.Back.clicked.connect(self.Page4) #goes back to page4 when user clicks back 
        self.Back.clicked.connect(Page5.close) #page5 closes when users clicks back

        # Check box for "once a week"
        self.OnceAWeek = QtWidgets.QRadioButton(self.centralwidget)
        self.OnceAWeek.setGeometry(QtCore.QRect(210, 180, 95, 20))
        self.OnceAWeek.setText("")
        self.OnceAWeek.setObjectName("OnceAWeek")
        # check box for "more than once a week"
        self.MoreThanAWeek = QtWidgets.QRadioButton(self.centralwidget)
        self.MoreThanAWeek.setGeometry(QtCore.QRect(210, 250, 95, 20))
        self.MoreThanAWeek.setText("")
        self.MoreThanAWeek.setObjectName("MoreThanAWeek")
        # check box for "Not at all"
        self.NotAtAll = QtWidgets.QRadioButton(self.centralwidget)
        self.NotAtAll.setGeometry(QtCore.QRect(210, 320, 95, 20))
        self.NotAtAll.setText("")
        self.NotAtAll.setObjectName("NotAtAll")
       
        Page5.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(Page5)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 498, 26))
        self.menubar.setObjectName("menubar")
        Page5.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(Page5)
        self.statusbar.setObjectName("statusbar")
        Page5.setStatusBar(self.statusbar)

        self.retranslateUi(Page5)
        QtCore.QMetaObject.connectSlotsByName(Page5)

    def retranslateUi(self, Page5):
        _translate = QtCore.QCoreApplication.translate
        Page5.setWindowTitle(_translate("Page5", "MainWindow"))
        self.label_10.setText(_translate("Page5", "<html><head/><body><p><span style=\" font-weight:600; color:#ffffff;\">More than <br/>once week</span></p></body></html>"))
        self.label_11.setText(_translate("Page5", "<html><head/><body><p><span style=\" font-weight:600; color:#ffffff;\">Not at all</span></p></body></html>"))
        self.label_12.setText(_translate("Page5", "How often do you exercise?"))
        self.label_13.setText(_translate("Page5", "<html><head/><body><p><span style=\" font-weight:600; color:#ffffff;\">Once a week</span></p></body></html>"))
        self.Continue.setText(_translate("Page5", "Continue"))
        self.Back.setText(_translate("Page5", "Back"))
import source5 # source to picture 


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Page5 = QtWidgets.QMainWindow()
    ui = Ui_Page5()
    ui.setupUi(Page5)
    Page5.show()
    sys.exit(app.exec_())
