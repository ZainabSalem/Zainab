
from PyQt5 import QtCore, QtGui, QtWidgets
from Page3 import Ui_Page3
import MySQLdb as mdb

class Ui_SignInPage(object):
    
    def Page3 (self):   #Method to connect pages together
                self.window2 = QtWidgets.QMainWindow()
                self.ui = Ui_Page3()
                self.ui.setupUi(self.window2)
                self.window2.show()
    
    def DB(self): # Method that connects with database and saves data
            
        try:
            connection = mdb.connect("localhost","root","root","coolmind")
            cursor = connection.cursor() # object
            print("Your are connected to Database")
            
            
            cursor = connection.cursor()
        except Exception as e:
            print("Database not connected")

        Email_text = self.Email_text.text()
        password_text = self.password_text.text()
        
        sql = (
        "INSERT INTO user(email,password)"
        "VALUES (%s, %s)"
        )
        
        data = (Email_text, password_text)
                
        try:
            cursor.execute(sql, data)
            connection.commit()
        except:
            connection.rollback()
            print("Data inserted")
            connection.close()          
        
    
    def setupUi(self, SignInPage):
        SignInPage.setObjectName("SignInPage")
        SignInPage.resize(491, 600)
        self.centralwidget = QtWidgets.QWidget(SignInPage)
        self.centralwidget.setObjectName("centralwidget")
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(-570, -80, 1591, 951))
        self.label.setStyleSheet("image: url(:/newPrefix/blue sky.jpg);")
        self.label.setText("")
        self.label.setObjectName("label")
        
        self.Email = QtWidgets.QLabel(self.centralwidget)
        self.Email.setGeometry(QtCore.QRect(50, 200, 241, 51))
        self.Email.setObjectName("Email")
        self.Email_text = QtWidgets.QLineEdit(self.centralwidget)
        self.Email_text.setGeometry(QtCore.QRect(50, 240, 351, 41))
        self.Email_text.setObjectName("Email_text")
        
        self.Password_2 = QtWidgets.QLabel(self.centralwidget)
        self.Password_2.setGeometry(QtCore.QRect(50, 320, 241, 51))
        self.Password_2.setObjectName("Password_2")
        
        self.password_text = QtWidgets.QLineEdit(self.centralwidget)
        self.password_text.setGeometry(QtCore.QRect(50, 360, 351, 41))
        self.password_text.setObjectName("password_text")
        
        self.SignIn = QtWidgets.QPushButton(self.centralwidget)
        self.SignIn.setGeometry(QtCore.QRect(160, 430, 141, 61))
        self.SignIn.setStyleSheet("font: 75 12pt \"MS Shell Dlg 2\";")
        self.SignIn.setObjectName("SignIn")
        
        #When user click "SignIn" next page opens and previous close 
        self.SignIn.clicked.connect(self.Page3)
        self.SignIn.clicked.connect(SignInPage.close)
        # When user click "SignIn" the database is connected and their data is saved
        self.SignIn.clicked.connect(self.DB)
        
        self.label_4 = QtWidgets.QLabel(self.centralwidget)
        self.label_4.setGeometry(QtCore.QRect(50, 140, 421, 31))
        self.label_4.setStyleSheet("font: 75 14pt \"MS Shell Dlg 2\";")
        self.label_4.setObjectName("label_4")
        SignInPage.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(SignInPage)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 491, 26))
        self.menubar.setObjectName("menubar")
        SignInPage.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(SignInPage)
        self.statusbar.setObjectName("statusbar")
        SignInPage.setStatusBar(self.statusbar)
        self.retranslateUi(SignInPage)
        QtCore.QMetaObject.connectSlotsByName(SignInPage)
        
    def retranslateUi(self, SignInPage):
        _translate = QtCore.QCoreApplication.translate
        SignInPage.setWindowTitle(_translate("SignInPage", "MainWindow"))
        self.Email.setText(_translate("SignInPage", "<html><head/><body><p><span style=\" font-size:16pt; font-weight:600; color:#ffffff;\">Email</span></p></body></html>"))
        self.Password_2.setText(_translate("SignInPage", "<html><head/><body><p><span style=\" font-size:16pt; font-weight:600; color:#ffffff;\">Password</span></p></body></html>"))
        self.SignIn.setText(_translate("SignInPage", "Sign in"))
        self.label_4.setText(_translate("SignInPage", "Enter your email and password to sign in"))
import source3ett


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    SignInPage = QtWidgets.QMainWindow()
    ui = Ui_SignInPage()
    ui.setupUi(SignInPage)
    SignInPage.show()
    sys.exit(app.exec_())
