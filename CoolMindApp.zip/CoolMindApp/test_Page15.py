from PyQt5 import QtCore, QtGui, QtWidgets
import MySQLdb as mdb 
import unittest
import Page15


class TestPage14(unittest.TestCase):
    
    # Test checkboxes "Yes,No,textbox" and pushbuttons "continue, back"
    def test_setupUi(self):
        # Identify the test values 
        Back = self.Back = QtWidgets.QPushButton
        Send = self.Send = QtWidgets.QPushButton
    
        pushButtons = Back, Send
        self.assertTrue(pushButtons) #Tests the values

    
    # Test connection to Database
    def test_DB(self):
        # Identify test values
        Back = self.Back = QtWidgets.QPushButton
        Send = self.Send = QtWidgets.QPushButton
        
        
        data = (Back, Send) 
       
        TestConnection = connection = mdb.connect("localhost","root","root","coolmind")
        cursor = connection.cursor() # object
        self.assertTrue(TestConnection)

        
if __name__ == '__main__':
        unittest.main()      
        