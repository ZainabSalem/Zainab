
from PyQt5 import QtCore, QtGui, QtWidgets
import unittest
import Page1


class TestPage1(unittest.TestCase):
    
    #Test if Page2 opens when signUp is clicked
    # and SignInPage open when LogIn is clicked 
    def test_setupUi(self):
        # Identify the test values which are "SignIn" button and "LogIn" button 
        SignUp = self.SignUp = QtWidgets.QPushButton
        LogIn = self.LogIn = QtWidgets.QPushButton 
        self.assertTrue(SignUp,LogIn) #Tests the buttons
        # If its true that Page2 and SignInPage open The test will not fail
        
        
if __name__ == '__main__':
        unittest.main()      
        
    
    
    
    
    