from PyQt5 import QtCore, QtGui, QtWidgets
import MySQLdb as mdb 
import unittest
import Page4
import Page5


class TestPage5(unittest.TestCase):
    
    # Test checkboxes "once a Week" and "More than once a week"
    def test_setupUi(self):
        # Identify the test values 
        onceAweek = self.OnceAWeek = QtWidgets.QRadioButton
        MoreThanAweek = self.MoreThanAWeek = QtWidgets.QRadioButton
        self.assertTrue(onceAweek,MoreThanAweek) #Tests the values
    
    # Test checkboxes "Not at all" and "Continue"
    def test__setupUi(self):
        NotAtAll = self.NotAtAll = QtWidgets.QRadioButton
        Continue = self.Continue = QtWidgets.QPushButton
        self.assertTrue(NotAtAll,Continue) #Tests the values if its true that they work, test will pass
    
    #Test "back" button   
    def test___setupUi(self):
        Back = self.Back = QtWidgets.QPushButton
        self.assertTrue(Back) #Tests the values if its true that they work, test will pass
        
    # Test connection to Database and inserted data to database
    def test_DB(self):
        onceAweek = self.OnceAWeek = QtWidgets.QRadioButton
        MoreThanAweek = self.MoreThanAWeek = QtWidgets.QRadioButton
        NotAtAll = self.NotAtAll = QtWidgets.QRadioButton
        
        sql = (  
        "INSERT INTO question3(onceAweek,MoreThanAweek,NotAtAll)"
        "VALUES (%s, %s, %s)"
        )
        data = (onceAweek,MoreThanAweek, NotAtAll)
       
        TestConnection = connection = mdb.connect("localhost","root","root","coolmind")
        cursor = connection.cursor() # object
        TestInsertedData= cursor.execute(sql, data)
        self.assertTrue(TestConnection, TestInsertedData)

        
if __name__ == '__main__':
        unittest.main()      
        