from PyQt5 import QtCore, QtGui, QtWidgets
import MySQLdb as mdb 
import unittest
import Page6
import Page7


class TestPage7(unittest.TestCase):
    
    # Test checkboxes "today" and "A few days ago"
    def test_setupUi(self):
        # Identify the test values 
        today = self.Today = QtWidgets.QRadioButton
        AFewDaysAgo = self.AFewDaysAgo = QtWidgets.QRadioButton
        self.assertTrue(today, AFewDaysAgo) #Tests the values
    
    # Test checkboxes "I DOnt know" and "Continue"
    def test__setupUi(self):
        IDontKnow = self.IDontKnow = QtWidgets.QRadioButton
        Continue = self.Continue = QtWidgets.QPushButton
        self.assertTrue(IDontKnow,Continue) #Tests the values if its true that they work, test will pass
    
    #Test "back" button   
    def test___setupUi(self):
        Back = self.Back = QtWidgets.QPushButton
        self.assertTrue(Back) #Tests the values if its true that they work, test will pass
        
    # Test connection to Database and inserted data to database
    def test_DB(self):
        # Identify test values
        Today = self.Today = QtWidgets.QRadioButton
        AFewDaysAgo = self.AFewDaysAgo = QtWidgets.QRadioButton
        IDontKnow = self.IDontKnow = QtWidgets.QRadioButton
        
        sql = (  
        "INSERT INTO question5(Today ,AFewDaysAgo, IDontKnow)"
        "VALUES (%s, %s, %s)"
        )
        data = (Today ,AFewDaysAgo, IDontKnow)
       
        TestConnection = connection = mdb.connect("localhost","root","root","coolmind")
        cursor = connection.cursor() # object
        TestInsertedData= cursor.execute(sql, data)
        self.assertTrue(TestConnection, TestInsertedData)

        
if __name__ == '__main__':
        unittest.main()      
        