
from PyQt5 import QtCore, QtGui, QtWidgets
import MySQLdb as mdb


class Ui_Page15(object):
    
    def Page14(self): # import and identify page14
        from Page14 import Ui_Page14
        self.window2 = QtWidgets.QMainWindow()
        self.ui = Ui_Page14()
        self.ui.setupUi(self.window2)
        self.window2.show()
    
    def Tips(self): # import and identify page tips
        from Tips import Ui_Tips
        self.window2 = QtWidgets.QMainWindow()
        self.ui = Ui_Tips()
        self.ui.setupUi(self.window2)
        self.window2.show()

    #def DB(self):  # Method that connects with database  
     
    
    def setupUi(self, Page15):
        #self.DB()
        Page15.setObjectName("Page15")
        Page15.resize(503, 619)
        self.centralwidget = QtWidgets.QWidget(Page15)
        self.centralwidget.setObjectName("centralwidget")
        # bluesky picture
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(-20, -430, 631, 1041))
        self.label.setStyleSheet("background-image: url(:/newPrefix/bluesky.jpg);")
        self.label.setText("")
        self.label.setObjectName("label")
        self.label_2 = QtWidgets.QLabel(self.centralwidget)
        self.label_2.setGeometry(QtCore.QRect(-360, -30, 1221, 861))
        self.label_2.setStyleSheet("image: url(:/newPrefix/blue sky.jpg);")
        self.label_2.setText("")
        self.label_2.setObjectName("label_2")
        # "thanks for answerign questions" text
        self.label_6 = QtWidgets.QLabel(self.centralwidget)
        self.label_6.setGeometry(QtCore.QRect(10, 170, 491, 181))
        self.label_6.setStyleSheet("font: 75 14pt \"MS Shell Dlg 2\";")
        self.label_6.setObjectName("label_6")
        # BAck button
        self.Back = QtWidgets.QPushButton(self.centralwidget)
        self.Back.setGeometry(QtCore.QRect(90, 460, 141, 61))
        self.Back.setStyleSheet("font: 75 16pt \"MS Shell Dlg 2\";\n"
"font: 14pt \"MS Shell Dlg 2\";\n"
"font: 16pt \"MS Shell Dlg 2\";\n"
"font: 14pt \"MS Shell Dlg 2\";")
        self.Back.setObjectName("Back") 
        self.Back.clicked.connect(self.Page14)
        self.Back.clicked.connect(Page15.close)
        # send button
        self.Send = QtWidgets.QPushButton(self.centralwidget)
        self.Send.setGeometry(QtCore.QRect(260, 460, 141, 61))
        self.Send.setStyleSheet("font: 75 16pt \"MS Shell Dlg 2\";\n"
"font: 14pt \"MS Shell Dlg 2\";\n"
"font: 16pt \"MS Shell Dlg 2\";\n"
"font: 14pt \"MS Shell Dlg 2\";")
        self.Send.setObjectName("Send")
        #self.Send.clicked.connect(self.DB)
        
        try: #checks if database is connected 
            connection = mdb.connect("localhost","root","root","coolmind")
            cursor = connection.cursor() # object
            print("Your are connected to Database")
            
            cursor = connection.cursor()
        except Exception as e:
            print("Database not connected")
            
      
    # fetch saved data from MYSQL Page3 and Page12
        cursor.execute(  
                "SELECT * FROM question_10 ORDER BY id DESC LIMIT 1;"
            )
        
        result = cursor.fetchall()
        data_question10 = result [0]
        print("answer to question 10 = ", data_question10) # prints out data from MYSQL to terminal as a tuple
            
        if data_question10[1]  == "1":
             self.Send.clicked.connect(Page15.close)
        
        if data_question10[2] == "1": # if checkbox "tips" and "Both" is TRUE(1) 
            self.Send.clicked.connect(self.Tips)
            self.Send.clicked.connect(Page15.close)
        
        if data_question10[3] == "1": # if checkbox "tips" and "Both" is TRUE(1) 
            self.Send.clicked.connect(self.Tips)
            self.Send.clicked.connect(Page15.close)
  
  
        
        
        Page15.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(Page15)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 503, 26))
        self.menubar.setObjectName("menubar")
        Page15.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(Page15)
        self.statusbar.setObjectName("statusbar")
        Page15.setStatusBar(self.statusbar)

        self.retranslateUi(Page15)
        QtCore.QMetaObject.connectSlotsByName(Page15)

    def retranslateUi(self, Page15):
        _translate = QtCore.QCoreApplication.translate
        Page15.setWindowTitle(_translate("Page15", "MainWindow"))
        self.label_6.setText(_translate("Page15", "<html><head/><body><p align=\"center\"><span style=\" font-size:18pt;\">Thanks for answering the questions. <br/>We hope you feel better soon!</span></p></body></html>"))
        self.Back.setText(_translate("Page15", "Back"))
        self.Send.setText(_translate("Page15", "Send"))
import source15


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Page15 = QtWidgets.QMainWindow()
    ui = Ui_Page15()
    ui.setupUi(Page15)
    Page15.show()
    sys.exit(app.exec_())
