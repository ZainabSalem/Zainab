from PyQt5 import QtCore, QtGui, QtWidgets
import MySQLdb as mdb 
import unittest
import Page5
import Page6


class TestPage6(unittest.TestCase):
    
    # Test checkboxes "once a Week" and "More than once a week"
    def test_setupUi(self):
        # Identify the test values 
        onceAweek =  self.OnceAWeek = QtWidgets.QRadioButton
        MoreThanOnceWeek = self.MoreThanOnceWeek = QtWidgets.QRadioButton
        self.assertTrue(onceAweek,MoreThanOnceWeek) #Tests the values
    
    # Test checkboxes "Not at all" and "Continue"
    def test__setupUi(self):
        NotAtAll = self.NotAtAll = QtWidgets.QRadioButton
        Continue = self.Continue = QtWidgets.QPushButton
        self.assertTrue(NotAtAll,Continue) #Tests the values if its true that they work, test will pass
    
    #Test "back" button   
    def test___setupUi(self):
        Back = self.Back = QtWidgets.QPushButton
        self.assertTrue(Back) #Tests the values if its true that they work, test will pass
        
    # Test connection to Database and inserted data to database
    def test_DB(self):
        onceAweek =  self.OnceAWeek = QtWidgets.QRadioButton
        MoreThanOnceWeek = self.MoreThanOnceWeek = QtWidgets.QRadioButton
        NotAtAll = self.NotAtAll = QtWidgets.QRadioButton
        
        sql = (  
        "INSERT INTO question4(onceAweek,MoreThanOnceweek,NotAtAll)"
        "VALUES (%s, %s, %s)"
        )
        
        data = (onceAweek,MoreThanOnceWeek, NotAtAll)
       
        TestConnection = connection = mdb.connect("localhost","root","root","coolmind")
        cursor = connection.cursor() # object
        TestInsertedData= cursor.execute(sql, data)
        self.assertTrue(TestConnection, TestInsertedData)

        
if __name__ == '__main__':
        unittest.main()      
        