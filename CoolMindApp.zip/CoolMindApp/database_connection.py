import MySQLdb as mdb 

try:
    connection = mdb.connect("localhost","root","root","coolmind")
    print("Database connected successfully")
    
except Exception as e:
    print ("Database not connected sucessfully")
    
    
#mycursor = mydb.cursor()   
#mycursor.execute("select * from user")
#result = mycursor.fetchall()


#for i in result:
    #print(i)
    