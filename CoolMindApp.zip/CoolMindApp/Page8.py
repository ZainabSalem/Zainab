
from PyQt5 import QtCore, QtGui, QtWidgets
import MySQLdb as mdb

class Ui_Page8(object):
    def DB(self):  # Method that connects with database and saves the data
        
        try: #checks if database is connected 
            connection = mdb.connect("localhost","root","root","coolmind")
            cursor = connection.cursor() # object
            print("Your are connected to Database")
            
            cursor = connection.cursor()
        except Exception as e:
            print("Database not connected")
        # declaire the checkboxes into variables 
        SitToNineHours= self.SitToNineHours.isChecked()
        LessThanSixHours = self.LessThanSixHours.isChecked() 
        IDontKnow = self.IDontKnow.isChecked()
        
        #collect all checkbox variables into variable "data"
        data = (SitToNineHours ,LessThanSixHours, IDontKnow)
        
        #SQL query that inserts data to table question1 in MYSQL
        sql = (  
        "INSERT INTO question6(SitToNineHours ,LessThanSixHours, IDontKnow)"
        "VALUES (%s, %s, %s)"
        )
              
        try: # checks if data is inserted
            cursor.execute(sql, data)
            connection.commit()
        except:
            connection.rollback()
            print("Data inserted")
            connection.close()   
    
    def Page7(self): #import and identify page7
        from Page7 import Ui_Page7
        self.window2 = QtWidgets.QMainWindow()
        self.ui = Ui_Page7()
        self.ui.setupUi(self.window2)
        self.window2.show()
    
    
    def Page9(self):  #import and identify page9
        from Page9 import Ui_Page9
        self.window2 = QtWidgets.QMainWindow()
        self.ui = Ui_Page9()
        self.ui.setupUi(self.window2)
        self.window2.show()
    
    
    def setupUi(self, Page8):
        Page8.setObjectName("Page8")
        Page8.resize(499, 614)
        self.centralwidget = QtWidgets.QWidget(Page8)
        self.centralwidget.setObjectName("centralwidget")
        # bluesky picture 
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(320, -130, 611, 1131))
        self.label.setStyleSheet("background-image: url(:/newPrefix/bluesky.jpg);")
        self.label.setText("")
        self.label.setObjectName("label")  
        self.label_2 = QtWidgets.QLabel(self.centralwidget)
        self.label_2.setGeometry(QtCore.QRect(-320, -50, 1171, 921))
        self.label_2.setStyleSheet("image: url(:/newPrefix/blue sky.jpg);")
        self.label_2.setText("")
        self.label_2.setObjectName("label_2")
        # "6-9 hours" text
        self.label_10 = QtWidgets.QLabel(self.centralwidget)
        self.label_10.setGeometry(QtCore.QRect(20, 130, 251, 41))
        self.label_10.setStyleSheet("font: 75 14pt \"MS Shell Dlg 2\";")
        self.label_10.setObjectName("label_10")
        # "less than 6 hours" text
        self.label_9 = QtWidgets.QLabel(self.centralwidget)
        self.label_9.setGeometry(QtCore.QRect(20, 190, 251, 41))
        self.label_9.setStyleSheet("font: 75 14pt \"MS Shell Dlg 2\";")
        self.label_9.setObjectName("label_9")
        # "I dont know" text
        self.label_8 = QtWidgets.QLabel(self.centralwidget)
        self.label_8.setGeometry(QtCore.QRect(20, 250, 251, 41))
        self.label_8.setStyleSheet("font: 75 14pt \"MS Shell Dlg 2\";")
        self.label_8.setObjectName("label_8")
        # "How many hours do sleep each night?" text
        self.label_5 = QtWidgets.QLabel(self.centralwidget)
        self.label_5.setGeometry(QtCore.QRect(20, 60, 401, 31))
        self.label_5.setStyleSheet("font: 75 14pt \"MS Shell Dlg 2\";")
        self.label_5.setObjectName("label_5")
        # continue button
        self.Continue = QtWidgets.QPushButton(self.centralwidget)
        self.Continue.setGeometry(QtCore.QRect(280, 460, 141, 61))
        self.Continue.setStyleSheet("font: 75 16pt \"MS Shell Dlg 2\";\n"
"font: 14pt \"MS Shell Dlg 2\";\n"
"font: 16pt \"MS Shell Dlg 2\";\n"
"font: 14pt \"MS Shell Dlg 2\";")
        self.Continue.setObjectName("Continue")
        self.Continue.clicked.connect(self.Page9) #Connects to page9
        self.Continue.clicked.connect(Page8.close) #Closes page8
        self.Continue.clicked.connect(self.DB) #Calls method DB and connects to database
        # "back button"
        self.Back = QtWidgets.QPushButton(self.centralwidget)
        self.Back.setGeometry(QtCore.QRect(110, 460, 141, 61))
        self.Back.setStyleSheet("font: 75 16pt \"MS Shell Dlg 2\";\n"
"font: 14pt \"MS Shell Dlg 2\";\n"
"font: 16pt \"MS Shell Dlg 2\";\n"
"font: 14pt \"MS Shell Dlg 2\";")
        self.Back.setObjectName("Back")
        self.Back.clicked.connect(self.Page7)
        self.Back.clicked.connect(Page8.close)
        # checkbox for "6-9 hours"
        self.SitToNineHours = QtWidgets.QRadioButton(self.centralwidget)
        self.SitToNineHours.setGeometry(QtCore.QRect(260, 140, 95, 20))
        self.SitToNineHours.setText("")
        self.SitToNineHours.setObjectName("SitToNineHours")
        # checkbox for "Less than 6 hours"
        self.LessThanSixHours = QtWidgets.QRadioButton(self.centralwidget)
        self.LessThanSixHours.setGeometry(QtCore.QRect(260, 200, 95, 20))
        self.LessThanSixHours.setText("")
        self.LessThanSixHours.setObjectName("LessThanSixHours")
        # checkbox for "I don´t"
        self.IDontKnow = QtWidgets.QRadioButton(self.centralwidget)
        self.IDontKnow.setGeometry(QtCore.QRect(260, 260, 95, 20))
        self.IDontKnow.setText("")
        self.IDontKnow.setObjectName("IDontKnow")
        Page8.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(Page8)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 499, 26))
        self.menubar.setObjectName("menubar")
        Page8.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(Page8)
        self.statusbar.setObjectName("statusbar")
        Page8.setStatusBar(self.statusbar)

        self.retranslateUi(Page8)
        QtCore.QMetaObject.connectSlotsByName(Page8)

    def retranslateUi(self, Page8):
        _translate = QtCore.QCoreApplication.translate
        Page8.setWindowTitle(_translate("Page8", "MainWindow"))
        self.label_10.setText(_translate("Page8", "<html><head/><body><p><span style=\" font-weight:600; color:#ffffff;\">6-9 hours</span></p></body></html>"))
        self.label_9.setText(_translate("Page8", "<html><head/><body><p><span style=\" font-weight:600; color:#ffffff;\">Less than 6 hours</span></p></body></html>"))
        self.label_8.setText(_translate("Page8", "<html><head/><body><p><span style=\" font-weight:600; color:#ffffff;\">I don´t know</span></p></body></html>"))
        self.label_5.setText(_translate("Page8", "How many hours do sleep each night?"))
        self.Continue.setText(_translate("Page8", "Continue"))
        self.Back.setText(_translate("Page8", "Back"))
import source8


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Page8 = QtWidgets.QMainWindow()
    ui = Ui_Page8()
    ui.setupUi(Page8)
    Page8.show()
    sys.exit(app.exec_())
