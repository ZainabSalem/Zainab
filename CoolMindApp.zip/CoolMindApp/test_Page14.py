from PyQt5 import QtCore, QtGui, QtWidgets
import MySQLdb as mdb 
import unittest
import Page14


class TestPage14(unittest.TestCase):
    
    # Test checkboxes "Yes,No,textbox" and pushbuttons "continue, back"
    def test_setupUi(self):
        # Identify the test values 
        YES = self.YES = QtWidgets.QRadioButton
        NO =  self.NO = QtWidgets.QRadioButton
        YES_TEXT = self.YES_TEXT = QtWidgets.QPlainTextEdit
        Back = self.Back = QtWidgets.QPushButton
        Continue = self.Continue_5 = QtWidgets.QPushButton
        test_values = YES, NO, YES_TEXT
        pushButtons = Back, Continue
        self.assertTrue(test_values, pushButtons) #Tests the values

    
    # Test connection to Database and inserted data to database
    def test_DB(self):
        # Identify test values
        YES = self.YES = QtWidgets.QRadioButton
        NO =  self.NO = QtWidgets.QRadioButton
        YES_TEXT = self.YES_TEXT = QtWidgets.QPlainTextEdit
        sql = (  
        "INSERT INTO question11(YES,NO, YES_TEXT)"
        "VALUES (%s, %s, %s)"
        )
        
        data = (YES,NO,YES_TEXT )
       
        TestConnection = connection = mdb.connect("localhost","root","root","coolmind")
        cursor = connection.cursor() # object
        TestInsertedData= cursor.execute(sql, data)
        self.assertTrue(TestConnection, TestInsertedData)

        
if __name__ == '__main__':
        unittest.main()      
        