
from PyQt5 import QtCore, QtGui, QtWidgets
import MySQLdb as mdb

class Ui_Page9(object):
    def DB(self):  # Method that connects with database and saves the data
        
        try: #checks if database is connected 
            connection = mdb.connect("localhost","root","root","coolmind")
            cursor = connection.cursor() # object
            print("Your are connected to Database")
            
            cursor = connection.cursor()
        except Exception as e:
            print("Database not connected")
        # declaire the checkboxes into variables 
        ONE= self.ONE.isChecked()
        TWO = self.TWO.isChecked() 
        THREE = self.THREE.isChecked()
        FOUR= self.FOUR.isChecked()
        
        #collect all checkbox variables into variable "data"
        data = (ONE ,TWO, THREE,FOUR)
        
        #SQL query that inserts data to table question1 in MYSQL
        sql = (  
        "INSERT INTO question7(ONE ,TWO, THREE,FOUR)"
        "VALUES (%s, %s, %s,%s)"
        )
              
        try: # checks if data is inserted
            cursor.execute(sql, data)
            connection.commit()
        except:
            connection.rollback()
            print("Data inserted")
            connection.close()   
    
    
   
    def Page8(self): # import and identify page8
        from Page8 import Ui_Page8
        self.window2 = QtWidgets.QMainWindow()
        self.ui = Ui_Page8()
        self.ui.setupUi(self.window2)
        self.window2.show()
    
    
    def Page10(self):  # imprt and identify page10 
        from Page10 import Ui_Page10
        self.window2 = QtWidgets.QMainWindow()
        self.ui = Ui_Page10()
        self.ui.setupUi(self.window2)
        self.window2.show()

    
    def setupUi(self, Page9):
        Page9.setObjectName("Page9")
        Page9.resize(501, 614)
        self.centralwidget = QtWidgets.QWidget(Page9)
        self.centralwidget.setObjectName("centralwidget")
        # bluesky Picture
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(-20, -450, 711, 1121))
        self.label.setStyleSheet("background-image: url(:/newPrefix/bluesky.jpg);")
        self.label.setText("")
        self.label.setObjectName("label")
        self.label_2 = QtWidgets.QLabel(self.centralwidget)
        self.label_2.setGeometry(QtCore.QRect(-330, -60, 1171, 921))
        self.label_2.setStyleSheet("image: url(:/newPrefix/blue sky.jpg);")
        self.label_2.setText("")
        self.label_2.setObjectName("label_2")
        # Question text
        self.label_9 = QtWidgets.QLabel(self.centralwidget)
        self.label_9.setGeometry(QtCore.QRect(20, 50, 451, 141))
        self.label_9.setStyleSheet("font: 75 14pt \"MS Shell Dlg 2\";")
        self.label_9.setObjectName("label_9")
        # "1" text
        self.label_10 = QtWidgets.QLabel(self.centralwidget)
        self.label_10.setGeometry(QtCore.QRect(30, 220, 51, 41))
        self.label_10.setStyleSheet("font: 75 14pt \"MS Shell Dlg 2\";")
        self.label_10.setObjectName("label_10")
        # "2" text
        self.label_11 = QtWidgets.QLabel(self.centralwidget)
        self.label_11.setGeometry(QtCore.QRect(30, 280, 51, 41))
        self.label_11.setStyleSheet("font: 75 14pt \"MS Shell Dlg 2\";")
        self.label_11.setObjectName("label_11")
        # "3" text
        self.label_12 = QtWidgets.QLabel(self.centralwidget)
        self.label_12.setGeometry(QtCore.QRect(30, 330, 51, 41))
        self.label_12.setStyleSheet("font: 75 14pt \"MS Shell Dlg 2\";")
        self.label_12.setObjectName("label_12")
         # "4" text
        self.label_13 = QtWidgets.QLabel(self.centralwidget)
        self.label_13.setGeometry(QtCore.QRect(30, 380, 51, 41))
        self.label_13.setStyleSheet("font: 75 14pt \"MS Shell Dlg 2\";")
        self.label_13.setObjectName("label_13")
        # continue button
        self.Continue_2 = QtWidgets.QPushButton(self.centralwidget)
        self.Continue_2.setGeometry(QtCore.QRect(280, 450, 141, 61))
        self.Continue_2.setStyleSheet("font: 75 16pt \"MS Shell Dlg 2\";\n"
"font: 14pt \"MS Shell Dlg 2\";\n"
"font: 16pt \"MS Shell Dlg 2\";\n"
"font: 14pt \"MS Shell Dlg 2\";")
        self.Continue_2.setObjectName("Continue_2")
        self.Continue_2.clicked.connect(self.Page10) #connects page 10
        self.Continue_2.clicked.connect(Page9.close) #Closes page9
        self.Continue_2.clicked.connect(self.DB) # calls method DB connects to database
        # back button
        self.Back = QtWidgets.QPushButton(self.centralwidget)
        self.Back.setGeometry(QtCore.QRect(110, 450, 141, 61))
        self.Back.setStyleSheet("font: 75 16pt \"MS Shell Dlg 2\";\n"
"font: 14pt \"MS Shell Dlg 2\";\n"
"font: 16pt \"MS Shell Dlg 2\";\n"
"font: 14pt \"MS Shell Dlg 2\";")
        self.Back.setObjectName("Back")
        self.Back.clicked.connect(self.Page8) #goes back to page8
        self.Back.clicked.connect(Page9.close) #closes page9
        # checkbox for "ONE"
        self.ONE = QtWidgets.QRadioButton(self.centralwidget)
        self.ONE.setGeometry(QtCore.QRect(80, 230, 95, 20))
        self.ONE.setText("")
        self.ONE.setObjectName("ONE")
        # checkbox for " TWO"
        self.TWO = QtWidgets.QRadioButton(self.centralwidget)
        self.TWO.setGeometry(QtCore.QRect(80, 290, 95, 20))
        self.TWO.setText("")
        self.TWO.setObjectName("TWO")
       # checkbox for "THREE"
        self.THREE = QtWidgets.QRadioButton(self.centralwidget)
        self.THREE.setGeometry(QtCore.QRect(80, 340, 95, 20))
        self.THREE.setText("")
        self.THREE.setObjectName("THREE")
        # checkbox for "FOUR"
        self.FOUR = QtWidgets.QRadioButton(self.centralwidget)
        self.FOUR.setGeometry(QtCore.QRect(80, 390, 95, 20))
        self.FOUR.setText("")
        self.FOUR.setObjectName("FOUR")
       
        Page9.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(Page9)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 501, 26))
        self.menubar.setObjectName("menubar")
        Page9.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(Page9)
        self.statusbar.setObjectName("statusbar")
        Page9.setStatusBar(self.statusbar)

        self.retranslateUi(Page9)
        QtCore.QMetaObject.connectSlotsByName(Page9)

    def retranslateUi(self, Page9):
        _translate = QtCore.QCoreApplication.translate
        Page9.setWindowTitle(_translate("Page9", "MainWindow"))
        self.label_9.setText(_translate("Page9", "<html><head/><body><p>How well-read are you in the subject.<br/>Choose from the scale 1- 4. <br/>1 stands for not familiar with the subject,<br/>4 is very familiar.</p></body></html>"))
        self.label_10.setText(_translate("Page9", "<html><head/><body><p><span style=\" font-weight:600; color:#ffffff;\">1</span></p></body></html>"))
        self.label_11.setText(_translate("Page9", "<html><head/><body><p><span style=\" font-weight:600; color:#ffffff;\">2</span></p></body></html>"))
        self.label_12.setText(_translate("Page9", "<html><head/><body><p><span style=\" font-weight:600; color:#ffffff;\">3</span></p></body></html>"))
        self.label_13.setText(_translate("Page9", "<html><head/><body><p><span style=\" font-weight:600; color:#ffffff;\">4</span></p></body></html>"))
        self.Continue_2.setText(_translate("Page9", "Continue"))
        self.Back.setText(_translate("Page9", "Back"))
import source9


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Page9 = QtWidgets.QMainWindow()
    ui = Ui_Page9()
    ui.setupUi(Page9)
    Page9.show()
    sys.exit(app.exec_())
