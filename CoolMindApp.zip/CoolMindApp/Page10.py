
from PyQt5 import QtCore, QtGui, QtWidgets
import MySQLdb as mdb

class Ui_Page10(object):
    def DB(self):  # Method that connects with database and saves the data
        
        try: #checks if database is connected 
            connection = mdb.connect("localhost","root","root","coolmind")
            cursor = connection.cursor() # object
            print("Your are connected to Database")
            
            cursor = connection.cursor()
        except Exception as e:
            print("Database not connected")
        # declaire the checkboxes into variables 
        YES= self.YES.isChecked()
        NO = self.NO.isChecked() 
        
        
        #collect all checkbox variables into variable "data"
        data = (YES,NO)
        
        #SQL query that inserts data to table question1 in MYSQL
        sql = (  
        "INSERT INTO question8(YES, NO)"
        "VALUES (%s, %s)"
        )
              
        try: # checks if data is inserted
            cursor.execute(sql, data)
            connection.commit()
        except:
            connection.rollback()
            print("Data inserted")
            connection.close()   
    
    
    def Page9(self): # import and identify page9
        from Page9 import Ui_Page9
        self.window2 = QtWidgets.QMainWindow()
        self.ui = Ui_Page9()
        self.ui.setupUi(self.window2)
        self.window2.show()
    
    
    def Page11(self): # import and identify page11
        from Page11 import Ui_Page11
        self.window2 = QtWidgets.QMainWindow()
        self.ui = Ui_Page11()
        self.ui.setupUi(self.window2)
        self.window2.show()

    
    def setupUi(self, Page10):
        Page10.setObjectName("Page10")
        Page10.resize(503, 612)
        self.centralwidget = QtWidgets.QWidget(Page10)
        self.centralwidget.setObjectName("centralwidget")
        # bluesky picture 
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(-20, -440, 581, 1051))
        self.label.setStyleSheet("background-image: url(:/newPrefix/bluesky.jpg);")
        self.label.setText("")
        self.label.setObjectName("label")
        self.label_2 = QtWidgets.QLabel(self.centralwidget)
        self.label_2.setGeometry(QtCore.QRect(-320, -50, 1181, 921))
        self.label_2.setStyleSheet("image: url(:/newPrefix/blue sky.jpg);")
        self.label_2.setText("")
        self.label_2.setObjectName("label_2")
        # "YES" text
        self.label_6 = QtWidgets.QLabel(self.centralwidget)
        self.label_6.setGeometry(QtCore.QRect(30, 140, 51, 41))
        self.label_6.setStyleSheet("font: 75 14pt \"MS Shell Dlg 2\";")
        self.label_6.setObjectName("label_6")
        # "NO" text
        self.label_8 = QtWidgets.QLabel(self.centralwidget)
        self.label_8.setGeometry(QtCore.QRect(30, 200, 51, 41))
        self.label_8.setStyleSheet("font: 75 14pt \"MS Shell Dlg 2\";")
        self.label_8.setObjectName("label_8")
        # Question text
        self.label_7 = QtWidgets.QLabel(self.centralwidget)
        self.label_7.setGeometry(QtCore.QRect(20, 50, 451, 51))
        self.label_7.setStyleSheet("font: 75 14pt \"MS Shell Dlg 2\";")
        self.label_7.setObjectName("label_7")
        # Continue button
        self.Continue = QtWidgets.QPushButton(self.centralwidget)
        self.Continue.setGeometry(QtCore.QRect(290, 450, 141, 61))
        self.Continue.setStyleSheet("font: 75 16pt \"MS Shell Dlg 2\";\n"
"font: 14pt \"MS Shell Dlg 2\";\n"
"font: 16pt \"MS Shell Dlg 2\";\n"
"font: 14pt \"MS Shell Dlg 2\";")
        self.Continue.setObjectName("Continue") 
        self.Continue.clicked.connect(self.Page11) #connect to page11
        self.Continue.clicked.connect(Page10.close) #close page10
        self.Continue.clicked.connect(self.DB) #calls db method and connects to database
        # back button
        self.Back = QtWidgets.QPushButton(self.centralwidget)
        self.Back.setGeometry(QtCore.QRect(120, 450, 141, 61))
        self.Back.setStyleSheet("font: 75 16pt \"MS Shell Dlg 2\";\n"
"font: 14pt \"MS Shell Dlg 2\";\n"
"font: 16pt \"MS Shell Dlg 2\";\n"
"font: 14pt \"MS Shell Dlg 2\";")
        self.Back.setObjectName("Back")
        self.Back.clicked.connect(self.Page9)
        self.Back.clicked.connect(Page10.close)
        # Checkbox for "YES"
        self.YES = QtWidgets.QRadioButton(self.centralwidget)
        self.YES.setGeometry(QtCore.QRect(100, 150, 95, 20))
        self.YES.setText("")
        self.YES.setObjectName("YES")
        # checkbox for "NO"
        self.NO = QtWidgets.QRadioButton(self.centralwidget)
        self.NO.setGeometry(QtCore.QRect(100, 210, 95, 20))
        self.NO.setText("")
        self.NO.setObjectName("NO")
       
        Page10.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(Page10)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 503, 26))
        self.menubar.setObjectName("menubar")
        Page10.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(Page10)
        self.statusbar.setObjectName("statusbar")
        Page10.setStatusBar(self.statusbar)

        self.retranslateUi(Page10)
        QtCore.QMetaObject.connectSlotsByName(Page10)

    def retranslateUi(self, Page10):
        _translate = QtCore.QCoreApplication.translate
        Page10.setWindowTitle(_translate("Page10", "MainWindow"))
        self.label_6.setText(_translate("Page10", "<html><head/><body><p><span style=\" font-weight:600; color:#ffffff;\">Yes</span></p></body></html>"))
        self.label_8.setText(_translate("Page10", "<html><head/><body><p><span style=\" font-weight:600; color:#ffffff;\">No</span></p></body></html>"))
        self.label_7.setText(_translate("Page10", "<html><head/><body><p>Do you have self-harming behavior?</p></body></html>"))
        self.Continue.setText(_translate("Page10", "Continue"))
        self.Back.setText(_translate("Page10", "Back"))
import source10


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Page10 = QtWidgets.QMainWindow()
    ui = Ui_Page10()
    ui.setupUi(Page10)
    Page10.show()
    sys.exit(app.exec_())
