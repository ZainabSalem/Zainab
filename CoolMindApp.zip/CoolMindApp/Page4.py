from PyQt5 import QtCore, QtGui, QtWidgets
import MySQLdb as mdb 

class Ui_Page4(object):
    
    def DB(self):  # Method that connects with database and saves the data
        
        try: #checks if database is connected 
            connection = mdb.connect("localhost","root","root","coolmind")
            cursor = connection.cursor() # object
            print("Your are connected to Database")
            
            cursor = connection.cursor()
        except Exception as e:
            print("Database not connected")
            
        # declaire the checkboxes into variables 
        onceAweek = self.OnceAWeek.isChecked()
        twiceAweek = self.TwiceAWeek.isChecked() 
        iDontknow = self.IDontKnow.isChecked()
        
        #collect all checkbox variables into variable "data"
        data = (onceAweek, twiceAweek,iDontknow)
        
        #SQL query that inserts data to table question1 in MYSQL
        sql = (  
        "INSERT INTO question2(onceAweek, twiceAweek,iDontknow)"
        "VALUES (%s, %s, %s)"
        )
              
        try: # checks if data is inserted
            cursor.execute(sql, data)
            connection.commit()
        except:
            connection.rollback()
            print("Data inserted")
            connection.close()   
    
    
    def Page3(self): #import and identify page3
        from Page3 import Ui_Page3
        self.window2 = QtWidgets.QMainWindow()
        self.ui = Ui_Page3()
        self.ui.setupUi(self.window2)
        self.window2.show()
    
    def Page5(self): #import and identify page5
        from Page5 import Ui_Page5
        self.window2 = QtWidgets.QMainWindow()
        self.ui = Ui_Page5()
        self.ui.setupUi(self.window2)
        self.window2.show()
        
    def setupUi(self, Page4):
        Page4.setObjectName("Page4")
        Page4.resize(498, 600)
        self.centralwidget = QtWidgets.QWidget(Page4)
        self.centralwidget.setObjectName("centralwidget")
        # blue sky picture
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(-330, -20, 1161, 821))
        self.label.setStyleSheet("image: url(:/newPrefix/blue sky.jpg);")
        self.label.setText("")
        self.label.setObjectName("label")
        # "How often fo you feel this way" text
        self.label_4 = QtWidgets.QLabel(self.centralwidget)
        self.label_4.setGeometry(QtCore.QRect(20, 70, 331, 31))
        self.label_4.setStyleSheet("font: 75 14pt \"MS Shell Dlg 2\";")
        self.label_4.setObjectName("label_4")
        # "Once a week" text
        self.label_8 = QtWidgets.QLabel(self.centralwidget)
        self.label_8.setGeometry(QtCore.QRect(30, 130, 191, 41))
        self.label_8.setStyleSheet("font: 75 14pt \"MS Shell Dlg 2\";")
        self.label_8.setObjectName("label_8")
        # "Twice a week" text
        self.label_6 = QtWidgets.QLabel(self.centralwidget)
        self.label_6.setGeometry(QtCore.QRect(30, 180, 191, 41))
        self.label_6.setStyleSheet("font: 75 14pt \"MS Shell Dlg 2\";")
        self.label_6.setObjectName("label_6")
        # "I don´t know" text
        self.label_9 = QtWidgets.QLabel(self.centralwidget)
        self.label_9.setGeometry(QtCore.QRect(30, 230, 191, 41))
        self.label_9.setStyleSheet("font: 75 14pt \"MS Shell Dlg 2\";")
        self.label_9.setObjectName("label_9")
        #Continue button
        self.Continue = QtWidgets.QPushButton(self.centralwidget)
        self.Continue.setGeometry(QtCore.QRect(250, 430, 141, 61))
        self.Continue.setStyleSheet("font: 75 16pt \"MS Shell Dlg 2\";\n"
"font: 14pt \"MS Shell Dlg 2\";\n"
"font: 16pt \"MS Shell Dlg 2\";\n"
"font: 14pt \"MS Shell Dlg 2\";")
        self.Continue.setObjectName("Continue")
        self.Continue.clicked.connect(self.Page5) #connects to Page5
        self.Continue.clicked.connect(Page4.close) #closes page4
        self.Continue.clicked.connect(self.DB) #connects to database, calls DB method
    
        # Back button
        self.Back = QtWidgets.QPushButton(self.centralwidget)
        self.Back.setGeometry(QtCore.QRect(70, 430, 141, 61))
        self.Back.setStyleSheet("font: 75 16pt \"MS Shell Dlg 2\";\n"
"font: 14pt \"MS Shell Dlg 2\";\n"
"font: 16pt \"MS Shell Dlg 2\";\n"
"font: 14pt \"MS Shell Dlg 2\";")
        self.Back.setObjectName("Back")
        self.Back.clicked.connect(self.Page3)
        self.Back.clicked.connect(Page4.close)

        self.OnceAWeek = QtWidgets.QRadioButton(self.centralwidget)
        self.OnceAWeek.setGeometry(QtCore.QRect(220, 140, 95, 20))
        self.OnceAWeek.setText("")
        self.OnceAWeek.setObjectName("OnceAWeek")
        
        self.TwiceAWeek = QtWidgets.QRadioButton(self.centralwidget)
        self.TwiceAWeek.setGeometry(QtCore.QRect(220, 190, 95, 20))
        self.TwiceAWeek.setText("")
        self.TwiceAWeek.setObjectName("TwiceAWeek")
        
        self.IDontKnow = QtWidgets.QRadioButton(self.centralwidget)
        self.IDontKnow.setGeometry(QtCore.QRect(220, 240, 95, 20))
        self.IDontKnow.setText("")
        self.IDontKnow.setObjectName("IDontKnow")
        Page4.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(Page4)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 498, 26))
        self.menubar.setObjectName("menubar")
        Page4.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(Page4)
        self.statusbar.setObjectName("statusbar")
        Page4.setStatusBar(self.statusbar)

        self.retranslateUi(Page4)
        QtCore.QMetaObject.connectSlotsByName(Page4)

    def retranslateUi(self, Page4):
        _translate = QtCore.QCoreApplication.translate
        Page4.setWindowTitle(_translate("Page4", "MainWindow"))
        self.label_4.setText(_translate("Page4", "How often do you feel this way?"))
        self.label_8.setText(_translate("Page4", "<html><head/><body><p><span style=\" font-weight:600; color:#ffffff;\">Once a week</span></p></body></html>"))
        self.label_6.setText(_translate("Page4", "<html><head/><body><p><span style=\" font-weight:600; color:#ffffff;\">Twice a week</span></p></body></html>"))
        self.label_9.setText(_translate("Page4", "<html><head/><body><p><span style=\" font-weight:600; color:#ffffff;\">I don´t know</span></p></body></html>"))
        self.Continue.setText(_translate("Page4", "Continue"))
        self.Back.setText(_translate("Page4", "Back"))
import source4 # source to blue sky picture


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Page4 = QtWidgets.QMainWindow()
    ui = Ui_Page4()
    ui.setupUi(Page4)
    Page4.show()
    sys.exit(app.exec_())
