
from PyQt5 import QtCore, QtGui, QtWidgets
import MySQLdb as mdb

class Ui_Page11(object):
    def DB(self):  # Method that connects with database and saves the data
        
        try: #checks if database is connected 
            connection = mdb.connect("localhost","root","root","coolmind")
            cursor = connection.cursor() # object
            print("Your are connected to Database")
            
            cursor = connection.cursor()
        except Exception as e:
            print("Database not connected")
        # declaire the checkboxes into variables 
        YES= self.YES.isChecked()
        NO = self.NO.isChecked() 
        
        
        #collect all checkbox variables into variable "data"
        data = (YES,NO)
        
        #SQL query that inserts data to table question9 in MYSQL
        sql = (  
        "INSERT INTO question9(YES, NO)"
        "VALUES (%s, %s)"
        )
              
        try: # checks if data is inserted
            cursor.execute(sql, data)
            connection.commit()
        except:
            connection.rollback()
            print("Data inserted")
            connection.close()   
    
    
    def Page10(self): # import and identify page10
        from Page10 import Ui_Page10
        self.window2 = QtWidgets.QMainWindow()
        self.ui = Ui_Page10()
        self.ui.setupUi(self.window2)
        self.window2.show()
    

    def Page12(self): #Import and identify page12
        from Page12 import Ui_Page12
        self.window2 = QtWidgets.QMainWindow()
        self.ui = Ui_Page12()
        self.ui.setupUi(self.window2)
        self.window2.show()

    # set up for page11
    def setupUi(self, Page11):
        Page11.setObjectName("Page11")
        Page11.resize(499, 613)
        self.centralwidget = QtWidgets.QWidget(Page11)
        self.centralwidget.setObjectName("centralwidget")
        # bluesky picture
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(-30, -440, 591, 1101))
        self.label.setStyleSheet("background-image: url(:/newPrefix/bluesky.jpg);")
        self.label.setText("")
        self.label.setObjectName("label")
        self.label_2 = QtWidgets.QLabel(self.centralwidget)
        self.label_2.setGeometry(QtCore.QRect(-370, -70, 1231, 921))
        self.label_2.setStyleSheet("image: url(:/newPrefix/blue sky.jpg);")
        self.label_2.setText("")
        self.label_2.setObjectName("label_2")
        # question text
        self.label_5 = QtWidgets.QLabel(self.centralwidget)
        self.label_5.setGeometry(QtCore.QRect(20, 70, 451, 61))
        self.label_5.setStyleSheet("font: 75 14pt \"MS Shell Dlg 2\";")
        self.label_5.setObjectName("label_5")
        # YES text
        self.label_8 = QtWidgets.QLabel(self.centralwidget)
        self.label_8.setGeometry(QtCore.QRect(30, 160, 51, 41))
        self.label_8.setStyleSheet("font: 75 14pt \"MS Shell Dlg 2\";")
        self.label_8.setObjectName("label_8")
        # NO text
        self.label_9 = QtWidgets.QLabel(self.centralwidget)
        self.label_9.setGeometry(QtCore.QRect(30, 220, 51, 41))
        self.label_9.setStyleSheet("font: 75 14pt \"MS Shell Dlg 2\";")
        self.label_9.setObjectName("label_9")
        # continue button
        self.Continue_2 = QtWidgets.QPushButton(self.centralwidget)
        self.Continue_2.setGeometry(QtCore.QRect(260, 440, 141, 61))
        self.Continue_2.setStyleSheet("font: 75 16pt \"MS Shell Dlg 2\";\n"
"font: 14pt \"MS Shell Dlg 2\";\n"
"font: 16pt \"MS Shell Dlg 2\";\n"
"font: 14pt \"MS Shell Dlg 2\";")
        self.Continue_2.setObjectName("Continue_2") 
        self.Continue_2.clicked.connect(self.Page12) # opens next window when user clicks continue
        self.Continue_2.clicked.connect(Page11.close) # closes current window when user clicks continue
        self.Continue_2.clicked.connect(self.DB)
        # back button
        self.Back = QtWidgets.QPushButton(self.centralwidget)
        self.Back.setGeometry(QtCore.QRect(90, 440, 141, 61))
        self.Back.setStyleSheet("font: 75 16pt \"MS Shell Dlg 2\";\n"
"font: 14pt \"MS Shell Dlg 2\";\n"
"font: 16pt \"MS Shell Dlg 2\";\n"
"font: 14pt \"MS Shell Dlg 2\";")
        self.Back.setObjectName("Back")
        self.Back.clicked.connect(self.Page10) # open previous window when user enters back
        self.Back.clicked.connect(Page11.close) #closes current window when user enters back
        #checkbox for YES
        self.YES = QtWidgets.QRadioButton(self.centralwidget)
        self.YES.setGeometry(QtCore.QRect(100, 170, 95, 20))
        self.YES.setText("")
        self.YES.setObjectName("YES")
        # checkbox for NO
        self.NO = QtWidgets.QRadioButton(self.centralwidget)
        self.NO.setGeometry(QtCore.QRect(100, 230, 95, 20))
        self.NO.setText("")
        self.NO.setObjectName("NO")
        Page11.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(Page11)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 499, 26))
        self.menubar.setObjectName("menubar")
        Page11.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(Page11)
        self.statusbar.setObjectName("statusbar")
        Page11.setStatusBar(self.statusbar)

        self.retranslateUi(Page11)
        QtCore.QMetaObject.connectSlotsByName(Page11)

    def retranslateUi(self, Page11):
        _translate = QtCore.QCoreApplication.translate
        Page11.setWindowTitle(_translate("Page11", "MainWindow"))
        self.label_5.setText(_translate("Page11", "<html><head/><body><p>Do you have suicidal thoughts?</p></body></html>"))
        self.label_8.setText(_translate("Page11", "<html><head/><body><p><span style=\" font-weight:600; color:#ffffff;\">Yes</span></p></body></html>"))
        self.label_9.setText(_translate("Page11", "<html><head/><body><p><span style=\" font-weight:600; color:#ffffff;\">No</span></p></body></html>"))
        self.Continue_2.setText(_translate("Page11", "Continue"))
        self.Back.setText(_translate("Page11", "Back"))
import source11


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Page11 = QtWidgets.QMainWindow()
    ui = Ui_Page11()
    ui.setupUi(Page11)
    Page11.show()
    sys.exit(app.exec_())
