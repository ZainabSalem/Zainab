
from PyQt5 import QtCore, QtGui, QtWidgets
import MySQLdb as mdb


class Ui_Page12(object):  
            
    def Page11(self): # import and identify page11
        from Page11 import Ui_Page11
        self.window2 = QtWidgets.QMainWindow()
        self.ui = Ui_Page11()
        self.ui.setupUi(self.window2)
        self.window2.show()
    
    
    def Page13(self): # import and identify page13
        from Page13 import Ui_Page13
        self.window2 = QtWidgets.QMainWindow()
        self.ui = Ui_Page13()
        self.ui.setupUi(self.window2)
        self.window2.show()
        
    def DB(self):  # Method that connects with database and saves the data
        
        try: #checks if database is connected 
            connection = mdb.connect("localhost","root","root","coolmind")
            cursor = connection.cursor() # object
            print("Your are connected to Database")
            
            cursor = connection.cursor()
        except Exception as e:
            print("Database not connected")
       
        # declaire the checkboxes into variables 
        C= self.CONTACTED.isChecked()
        T = self.TIPS.isChecked() 
        B = self.BOTH.isChecked() 
        
        #collect all checkbox variables into variable "data"
        data = (C,T,B)
        
        #SQL query that inserts data to table question10 in MYSQL
        sql = (  
        "INSERT INTO question_10(`CONTACTED`, `TIPS`, `BOTH`)"
        "VALUES (%s, %s, %s)"
        )   
        try: # checks if data is inserted
            cursor.execute(sql, data)
            connection.commit()
        except:
            connection.rollback()
            print("Data inserted")
            connection.close()     
    # set up dor page12
    def setupUi(self, Page12):
        Page12.setObjectName("Page12")
        Page12.resize(500, 616)
        self.centralwidget = QtWidgets.QWidget(Page12)
        self.centralwidget.setObjectName("centralwidget")
        #blue sky picture
        self.label_2 = QtWidgets.QLabel(self.centralwidget)
        self.label_2.setGeometry(QtCore.QRect(-310, -70, 1141, 921))
        self.label_2.setStyleSheet("image: url(:/newPrefix/blue sky.jpg);")
        self.label_2.setText("")
        self.label_2.setObjectName("label_2")
        # contacted text
        self.label_9 = QtWidgets.QLabel(self.centralwidget)
        self.label_9.setGeometry(QtCore.QRect(20, 160, 121, 41))
        self.label_9.setStyleSheet("font: 75 14pt \"MS Shell Dlg 2\";")
        self.label_9.setObjectName("label_9")
        # tips text
        self.label_10 = QtWidgets.QLabel(self.centralwidget)
        self.label_10.setGeometry(QtCore.QRect(20, 220, 51, 41))
        self.label_10.setStyleSheet("font: 75 14pt \"MS Shell Dlg 2\";")
        self.label_10.setObjectName("label_10")
        # Both text
        self.label_11 = QtWidgets.QLabel(self.centralwidget)
        self.label_11.setGeometry(QtCore.QRect(20, 280, 71, 41))
        self.label_11.setStyleSheet("font: 75 14pt \"MS Shell Dlg 2\";")
        self.label_11.setObjectName("label_11")
        # question text
        self.label_6 = QtWidgets.QLabel(self.centralwidget)
        self.label_6.setGeometry(QtCore.QRect(10, 60, 451, 81))
        self.label_6.setStyleSheet("font: 75 14pt \"MS Shell Dlg 2\";")
        self.label_6.setObjectName("label_6")
         # continue button
        self.Continue_3 = QtWidgets.QPushButton(self.centralwidget)
        self.Continue_3.setGeometry(QtCore.QRect(280, 440, 141, 61))
        self.Continue_3.setStyleSheet("font: 75 16pt \"MS Shell Dlg 2\";\n"
"font: 14pt \"MS Shell Dlg 2\";\n"
"font: 16pt \"MS Shell Dlg 2\";\n"
"font: 14pt \"MS Shell Dlg 2\";")
        self.Continue_3.setObjectName("Continue_3")
        self.Continue_3.clicked.connect(self.Page13) # when user clicks continue next window opens
        self.Continue_3 .clicked.connect(Page12.close) # when user clicks continue current window closes
        self.Continue_3 .clicked.connect(self.DB) #when user clicks continue the database is connected 
        # back button
        self.Back = QtWidgets.QPushButton(self.centralwidget)
        self.Back.setGeometry(QtCore.QRect(110, 440, 141, 61))
        self.Back.setStyleSheet("font: 75 16pt \"MS Shell Dlg 2\";\n"
"font: 14pt \"MS Shell Dlg 2\";\n"
"font: 16pt \"MS Shell Dlg 2\";\n"
"font: 14pt \"MS Shell Dlg 2\";")
        self.Back.setObjectName("Back")
        self.Back.clicked.connect(self.Page11) # when user enters back open previous window
        self.Back.clicked.connect(Page12.close) # when user enters back current window closes
        # checkbox for contacted
        self.CONTACTED = QtWidgets.QRadioButton(self.centralwidget)
        self.CONTACTED.setGeometry(QtCore.QRect(170, 170, 95, 20))
        self.CONTACTED.setText("")
        self.CONTACTED.setObjectName("CONTACTED")
        # checkbox for tips
        self.TIPS = QtWidgets.QRadioButton(self.centralwidget)
        self.TIPS.setGeometry(QtCore.QRect(170, 230, 95, 20))
        self.TIPS.setText("")
        self.TIPS.setObjectName("TIPS")
        # checkbox for both
        self.BOTH = QtWidgets.QRadioButton(self.centralwidget)
        self.BOTH.setGeometry(QtCore.QRect(170, 290, 95, 20))
        self.BOTH.setText("")
        self.BOTH.setObjectName("BOTH")
        Page12.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(Page12)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 500, 26))
        self.menubar.setObjectName("menubar")
        Page12.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(Page12)
        self.statusbar.setObjectName("statusbar")
        Page12.setStatusBar(self.statusbar)

        self.retranslateUi(Page12)
        QtCore.QMetaObject.connectSlotsByName(Page12)

    def retranslateUi(self, Page12):
        _translate = QtCore.QCoreApplication.translate
        Page12.setWindowTitle(_translate("Page12", "MainWindow"))
        self.label_9.setText(_translate("Page12", "<html><head/><body><p><span style=\" font-weight:600; color:#ffffff;\">Contacted</span></p></body></html>"))
        self.label_10.setText(_translate("Page12", "<html><head/><body><p><span style=\" font-weight:600; color:#ffffff;\">Tips</span></p></body></html>"))
        self.label_11.setText(_translate("Page12", "<html><head/><body><p><span style=\" font-weight:600; color:#ffffff;\">Both</span></p></body></html>"))
        self.label_6.setText(_translate("Page12", "<html><head/><body><p>Do you want to be contacted or receive tips?</p></body></html>"))
        self.Continue_3.setText(_translate("Page12", "Continue"))
        self.Back.setText(_translate("Page12", "Back"))
import source12


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Page12 = QtWidgets.QMainWindow()
    ui = Ui_Page12()
    ui.setupUi(Page12)
    Page12.show()
    sys.exit(app.exec_())
