from PyQt5 import QtCore, QtGui, QtWidgets
import MySQLdb as mdb 
import unittest
import Page14


class TestPage14(unittest.TestCase):
    
    # Test textbox for "Email and password" and pushbutton "Sign in"
    def test_setupUi(self):
        # Identify the test values 
        Email_text = self.Email_text = QtWidgets.QLineEdit
        password_text=  self.password_text = QtWidgets.QLineEdit
        SignIn = self.SignIn = QtWidgets.QPushButton
        test_values = Email_text, password_text, SignIn
        self.assertTrue(test_values) #Tests the values

    
    # Test connection to Database and inserted data to database
    def test_DB(self):
        # Identify test values
        Email_text = self.Email_text = QtWidgets.QLineEdit
        password_text=  self.password_text = QtWidgets.QLineEdit
                
        sql = (
        "INSERT INTO user(email,password)"
        "VALUES (%s, %s)"
        )
        
        data = (Email_text, password_text)
       
        TestConnection = connection = mdb.connect("localhost","root","root","coolmind")
        cursor = connection.cursor() # object
        TestInsertedData= cursor.execute(sql, data)
        self.assertTrue(TestConnection, TestInsertedData)

        
if __name__ == '__main__':
        unittest.main()      
        