

import email
from tkinter import messagebox
from PyQt5 import QtCore, QtGui, QtWidgets
import MySQLdb as mdb 

class Ui_Page2(object):
     
                                                               
    def Page3 (self): #import and identify page3
        from Page3 import Ui_Page3
        self.window2 = QtWidgets.QMainWindow()
        self.ui = Ui_Page3()
        self.ui.setupUi(self.window2)
        self.window2.show()
    
    def DB(self):  # Method that connects with database and saves data
        import MySQLdb as mdb 
        try:
            connection = mdb.connect("localhost","root","root","coolmind")
            cursor = connection.cursor() # object
            print("Your are connected to Database")
            
            
            cursor = connection.cursor()
        except Exception as e:
            print("Database not connected")

        fullname = self.FullName_text.text()
        email = self.Email_text.text()
        password = self.password_text.text()
        
        sql = (
        "INSERT INTO account(fullname,email,password)"
        "VALUES (%s, %s, %s)"
        )
        
        data = (fullname, email, password)
                
        try:
            cursor.execute(sql, data)
            connection.commit()
        except:
            connection.rollback()
            print("Data inserted")
            connection.close()  
            

    def setupUi(self, Page2):
        Page2.setObjectName("Page2")
        Page2.resize(481, 600)
        self.centralwidget = QtWidgets.QWidget(Page2)
        self.centralwidget.setObjectName("centralwidget")
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(-300, 0, 1121, 851))
        self.label.setStyleSheet("image: url(:/newPrefix/blue sky.jpg);")
        self.label.setText("")
        self.label.setObjectName("label")
        
        self.FullName_text = QtWidgets.QLineEdit(self.centralwidget)
        self.FullName_text.setGeometry(QtCore.QRect(60, 140, 351, 41))
        self.FullName_text.setObjectName("FullName_text")
        self.FullName = QtWidgets.QLabel(self.centralwidget)
        self.FullName.setGeometry(QtCore.QRect(60, 100, 241, 51))
        self.FullName.setObjectName("FullName")
        
        self.Email_text = QtWidgets.QLineEdit(self.centralwidget)
        self.Email_text.setGeometry(QtCore.QRect(60, 250, 351, 41))
        self.Email_text.setObjectName("Email_text")
        self.Email = QtWidgets.QLabel(self.centralwidget)
        self.Email.setGeometry(QtCore.QRect(60, 210, 241, 51))
        self.Email.setObjectName("Email")
       
        self.password_text = QtWidgets.QLineEdit(self.centralwidget)
        self.password_text.setGeometry(QtCore.QRect(60, 360, 351, 41))
        self.password_text.setObjectName("password_text")
        self.Password = QtWidgets.QLabel(self.centralwidget)
        self.Password.setGeometry(QtCore.QRect(60, 320, 241, 51))
        self.Password.setObjectName("Password")
        self.Register = QtWidgets.QPushButton(self.centralwidget)
        self.Register.setGeometry(QtCore.QRect(160, 450, 141, 61))
        self.Register.setStyleSheet("font: 75 12pt \"MS Shell Dlg 2\";")
        self.Register.setObjectName("Register")
        
        #When user click "SignIn" next page opens and previous close 
        self.Register.clicked.connect(self.Page3)
        self.Register.clicked.connect(Page2.close)
        # When clicked on "Register" the database is connected
        self.Register.clicked.connect(self.DB)
        
        
        Page2.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(Page2)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 481, 26))
        self.menubar.setObjectName("menubar")
        Page2.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(Page2)
        self.statusbar.setObjectName("statusbar")
        Page2.setStatusBar(self.statusbar)

        self.retranslateUi(Page2)
        QtCore.QMetaObject.connectSlotsByName(Page2)

    def retranslateUi(self, Page2):
        _translate = QtCore.QCoreApplication.translate
        Page2.setWindowTitle(_translate("Page2", "MainWindow"))
        self.FullName.setText(_translate("Page2", "<html><head/><body><p><span style=\" font-size:16pt; font-weight:600; color:#ffffff;\">Full Name</span></p></body></html>"))
        self.Email.setText(_translate("Page2", "<html><head/><body><p><span style=\" font-size:16pt; font-weight:600; color:#ffffff;\">Email</span></p></body></html>"))
        self.Password.setText(_translate("Page2", "<html><head/><body><p><span style=\" font-size:16pt; font-weight:600; color:#ffffff;\">Password</span></p></body></html>"))
        self.Register.setText(_translate("Page2", "Register"))           
import source1

if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Page2 = QtWidgets.QMainWindow()
    ui = Ui_Page2()
    ui.setupUi(Page2)
    Page2.show()
    sys.exit(app.exec_())
